import numpy as np
import os
import joblib
import csv
from tqdm import tqdm
from datetime import datetime

# 配置参数
MODEL_DIR = "./multitask_model__ViT-L14_inpost.pkl"  # 模型目录
FEATURE_DIR = "./brady_ViT-L14_inpost_activations"     # 批量特征文件目录
OUTPUT_CSV = "./brady_ViT-L14_predictions.csv"     # 结果保存路径
ERROR_LOG = "./error_log.txt"        # 错误日志路径

def batch_predict():
    """批量预测主流程"""
    # 准备输出文件
    header = ["filename"] + [f"dim_{i+1:02d}" for i in range(49)]
    
    with open(OUTPUT_CSV, "w", newline="") as csvfile, \
         open(ERROR_LOG, "w") as logfile:
        
        writer = csv.writer(csvfile)
        writer.writerow(header)
        
        # 获取特征文件列表
        feature_files = [f for f in os.listdir(FEATURE_DIR) 
                        if f.endswith(".npy")]
        if not feature_files:
            raise FileNotFoundError(f"{FEATURE_DIR} 中没有找到.npy特征文件")
        
        # 加载所有模型到内存（提升速度）
        print("正在加载模型...")
        models = [joblib.load(os.path.join(MODEL_DIR, f"model_dim_{i}.pkl")) 
                 for i in range(49)]
        
        # 批量处理
        print(f"正在处理 {len(feature_files)} 个特征文件：")
        for idx, fname in enumerate(tqdm(feature_files)):
            try:
                # 加载特征
                feature_path = os.path.join(FEATURE_DIR, fname)
                raw_feature = np.load(feature_path).flatten()
                processed = raw_feature.reshape(1, -1)
                
                # 执行预测
                predictions = [model.predict(processed)[0] for model in models]
                
                # 写入结果
                writer.writerow([fname] + predictions)
                
            except Exception as e:
                log_msg = f"{datetime.now()} - 文件 {fname} 处理失败: {str(e)}\n"
                logfile.write(log_msg)
                continue

if __name__ == "__main__":
    # 自动创建必要目录
    os.makedirs(FEATURE_DIR, exist_ok=True)
    
    try:
        batch_predict()
        print(f"\n预测完成！结果已保存至 {OUTPUT_CSV}")
        if os.path.exists(ERROR_LOG) and os.path.getsize(ERROR_LOG) > 0:
            print(f"警告：部分文件处理失败，详见 {ERROR_LOG}")
    except Exception as e:
        print(f"程序异常终止: {str(e)}")
