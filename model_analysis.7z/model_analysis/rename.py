import os
import re

def batch_rename(directory):
    print(f"目标目录: {directory}")  # 显示实际路径
    if not os.path.exists(directory):
        print("错误: 目录不存在")
        return

    for filename in os.listdir(directory):
        print(f"处理文件: {filename}")  # 调试输出
        match = re.match(r'^model_dim_(\d+)\.pkl$', filename)
        if match:
            number = int(match.group(1))-1
            new_number = f"{number:d}"
            new_filename = f"model_dim_{new_number}.pkl"
            old_path = os.path.join(directory, filename)
            new_path = os.path.join(directory, new_filename)

            if os.path.exists(new_path):
                print(f"冲突跳过: {new_filename} 已存在")
                continue

            try:
                os.rename(old_path, new_path)
                print(f"成功: {filename} → {new_filename}")
            except Exception as e:
                print(f"失败: {filename} → 错误: {e}")
        else:
            print(f"忽略: {filename}（格式不匹配）")

# 示例调用（替换为你的实际路径）
batch_rename("./multitask_model__ViT-L14_inpost.pkl")
