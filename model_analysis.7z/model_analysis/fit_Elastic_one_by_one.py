import numpy as np
import os
from sklearn.linear_model import ElasticNet
from sklearn.model_selection import GridSearchCV, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
import joblib


# 配置参数
FEATURE_DIR = "./Things_ViT-L14_inpost_activations"       # 特征文件存放目录
SCORE_PATH = "spose_embedding_49d_sorted.txt"      # 分数文件路径
MODEL_DIR = "multitask_model__ViT-L14_inpost.pkl"  # 模型保存路径
N_FOLDS = 10                   # 交叉验证折数
N_JOBS = -1                    # 使用所有CPU核心


# 创建模型目录
os.makedirs(MODEL_DIR, exist_ok=True)


# 加载特征数据
def load_features():
    features = []
    file_list = sorted([f for f in os.listdir(FEATURE_DIR) if f.endswith(".npy")])

    for file_name in file_list:
        activation = np.load(os.path.join(FEATURE_DIR, file_name))
        flat_activation = activation.flatten()
        features.append(flat_activation)

    #print(features)
    return np.array(features)

# 从txt文件加载分数数据
def load_scores():
    scores = []
    with open(SCORE_PATH, 'r') as f:
        lines = f.readlines()
        for line in lines:
            line_scores = list(map(float, line.strip().split()))
            scores.append(line_scores)
    return np.array(scores)


# 定义训练流程
def train_elastic_net(X, y):
    # 创建预处理 + 模型管道
    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('en', ElasticNet(max_iter=10000))
    ])

    # 参数搜索空间
    param_grid = {
        'en__alpha': np.logspace(-4, 2, 7),
        'en__l1_ratio': np.linspace(0.1, 0.9, 5)
    }

    # 创建交叉验证搜索器
    grid_search = GridSearchCV(
        estimator=pipeline,
        param_grid=param_grid,
        cv=KFold(n_splits=N_FOLDS, shuffle=True),
        scoring='neg_mean_squared_error',
        n_jobs=N_JOBS
    )

    grid_search.fit(X, y)
    return grid_search.best_estimator_


# 主流程
def main():
    # 加载数据
    X = load_features()
    Y = load_scores()

    # 为每个评分维度训练模型
    for dim in range(Y.shape[1]):
        print(f"Training model for dimension {dim + 1}/{Y.shape[1]}")
        model = train_elastic_net(X, Y[:, dim])

        # 保存模型
        joblib.dump(model, os.path.join(MODEL_DIR, f"model_dim_{dim}.pkl"))


# 新数据预测示例
def predict_new_image(image_path):
    # 加载并处理新图片特征
    activation = np.load(image_path)
    flat_activation = activation.flatten().reshape(1, -1)
    # 加载所有模型并预测
    predictions = np.zeros(49)
    for dim in range(49):
        model = joblib.load(os.path.join(MODEL_DIR, f"model_dim_{dim}.pkl"))
        predictions[dim] = model.predict(flat_activation)
    return predictions


if __name__ == "__main__":
    main()
