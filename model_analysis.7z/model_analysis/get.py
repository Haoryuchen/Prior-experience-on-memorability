import numpy as np
import os
import joblib

# 配置参数
MODEL_DIR = "./multitask_model.pkl"  # 与训练代码中的模型目录一致
NEW_IMAGE_PATH = "./Things_activations/Things_1.npy"  # 新图片特征文件路径

def predict_new_image(image_path):
    # 加载并处理新图片特征
    activation = np.load(image_path)
    flat_activation = activation.flatten().reshape(1, -1)
    
    # 加载所有模型并预测
    predictions = np.zeros(49)
    for dim in range(49):
        model = joblib.load(os.path.join(MODEL_DIR, f"model_dim_{dim}.pkl"))
        # 关键修改：提取预测结果的第一个元素
        predictions[dim] = model.predict(flat_activation)[0]  # 添加[0]索引
        
    return predictions

# 关键标准化说明
'''
Q：为什么不需要手动标准化？
A：训练时使用的 Pipeline 包含 StandardScaler，每个保存的模型已经内置了标准化器。
当调用 model.predict() 时，输入数据会自动进行以下处理：
1. 使用训练时计算的均值和方差进行标准化
2. 将标准化后的数据输入弹性网络模型
'''

# 示例使用
if __name__ == "__main__":
    # 验证特征维度
    sample_feature = np.load(NEW_IMAGE_PATH).flatten()
    print(f"特征维度验证：{len(sample_feature)}维（应与训练时的一致）")
    
    # 执行预测
    result = predict_new_image(NEW_IMAGE_PATH)
    print("预测结果（49维评分）：")
    print(result)

# 常见问题解决方案
'''
1. 维度不匹配错误：
   - 检查激活值的提取层是否与训练时一致
   - 使用相同的网络架构提取特征

2. 标准化一致性验证：
   - 可以通过以下代码验证第一个维度的标准化参数：
   first_model = joblib.load(os.path.join(MODEL_DIR, "model_dim_0.pkl"))
   print("标准化均值：", first_model.named_steps['scaler'].mean_)
   print("标准化方差：", first_model.named_steps['scaler'].scale_)

3. 批量预测优化：
   - 修改函数支持多图片输入
   - 预加载所有模型到内存，避免重复IO消耗
'''
