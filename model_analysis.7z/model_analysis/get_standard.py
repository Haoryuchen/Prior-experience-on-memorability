import numpy as np
import os
import joblib
import csv
from tqdm import tqdm
from datetime import datetime
from sklearn.preprocessing import StandardScaler

# 配置参数
MODEL_DIR = "./multitask_model.pkl"
FEATURE_DIR = "./Things_activations"
OUTPUT_CSV = "./predictions_estimated_scaler.csv"
ERROR_LOG = "./error_log.txt"
MIN_SAMPLES = 50  # 至少需要50个样本估计标准化器

def estimate_scaler_safe(feature_dir):
    """
    安全地估计标准化器（带统计验证）
    :return: StandardScaler对象
    :raises ValueError: 数据量不足或分布异常
    """
    feature_files = [f for f in os.listdir(feature_dir) if f.endswith(".npy")]
    if len(feature_files) < MIN_SAMPLES:
        raise ValueError(f"至少需要 {MIN_SAMPLES} 个样本，当前只有 {len(feature_files)} 个")
    
    # 加载所有特征
    features = []
    for fname in tqdm(feature_files, desc="加载特征"):
        feat = np.load(os.path.join(feature_dir, fname)).flatten()
        features.append(feat)
    X = np.array(features)
    
    # 分布验证
    feature_means = X.mean(axis=0)
    if np.any(np.abs(feature_means) > 100):
        raise ValueError("特征均值超过±100，可能不符合标准化前提条件")
    
    # 训练新标准化器
    new_scaler = StandardScaler().fit(X)
    
    # 验证标准化效果
    X_scaled = new_scaler.transform(X)
    scaled_means = X_scaled.mean(axis=0)
    scaled_stds = X_scaled.std(axis=0)
    
    if np.max(np.abs(scaled_means)) > 1e-3:
        raise ValueError("标准化后均值偏离过大（应接近0）")
    if np.max(np.abs(scaled_stds - 1)) > 0.1:
        raise ValueError("标准化后标准差偏离过大（应接近1）")
    
    return new_scaler

def batch_predict_with_estimated_scaler():
    """使用估计的标准化器进行预测"""
    try:
        # 安全估计标准化器
        scaler = estimate_scaler_safe(FEATURE_DIR)
        print("\n标准化器验证通过，均值误差: {:.4f}，方差误差: {:.4f}".format(
            np.abs(scaler.mean_).max(),
            np.abs(scaler.scale_ - 1).max()
        ))
        
        # 加载模型
        models = [joblib.load(os.path.join(MODEL_DIR, f"model_dim_{i}.pkl")) 
                 for i in range(49)]
        
        # 执行预测
        with open(OUTPUT_CSV, "w", newline="") as csvfile, \
             open(ERROR_LOG, "w") as logfile:
            
            writer = csv.writer(csvfile)
            writer.writerow(["filename"] + [f"dim_{i+1:02d}" for i in range(49)])
            
            feature_files = os.listdir(FEATURE_DIR)
            for fname in tqdm(feature_files, desc="预测中"):
                try:
                    # 加载并标准化
                    raw = np.load(os.path.join(FEATURE_DIR, fname)).flatten()
                    processed = scaler.transform(raw.reshape(1, -1))
                    
                    # 预测
                    preds = [model.predict(processed)[0] for model in models]
                    writer.writerow([fname] + preds)
                
                except Exception as e:
                    logfile.write(f"{datetime.now()} - {fname} 错误: {str(e)}\n")
    
    except Exception as e:
        print(f"\n严重错误: {str(e)}")
        print("建议解决方案:")
        print("1. 确保预测数据量足够（>{}个样本）".format(MIN_SAMPLES))
        print("2. 检查特征文件是否包含异常值")
        print("3. 考虑使用其他补救方案")

if __name__ == "__main__":
    os.makedirs(FEATURE_DIR, exist_ok=True)
    batch_predict_with_estimated_scaler()
