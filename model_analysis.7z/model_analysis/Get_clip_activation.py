## This code is for training model to predict 49 dimensions score of pictures

import torch
import clip
import os
from PIL import Image
from pathlib import Path
import numpy as np

# 配置参数
class Config:
    image_dir = "./Things_clip/Things/variables/Things_objects"         # 图片目录
    batch_size = 16               # 根据GPU内存调整
    output_dir = "./Things_ViT-L14_inpost_activations"   # 特征保存路径
    model_name = "ViT-L/14"        # 可选模型：RN50, ViT-B/32, ViT-L/14等

# 初始化环境
device = "cuda" if torch.cuda.is_available() else "cpu"
model, preprocess = clip.load(Config.model_name, device=device)
Path(Config.output_dir).mkdir(parents=True, exist_ok=True)

print(model.visual)
# 注册hook捕获特征
activation = {}
def get_activation(name):
    def hook(module, input, output):
        activation[name] = output.detach().cpu().numpy()
    return hook
hook = model.visual.ln_post.register_forward_hook(get_activation('features'))

# 批量处理函数
def process_batch(image_batch, filenames):
    with torch.no_grad():
        image_tensor = torch.stack(image_batch).to(device)
        _ = model.encode_image(image_tensor)
    
    # 保存为numpy格式
    features = activation['features']
    for i, fn in enumerate(filenames):
        save_path = os.path.join(Config.output_dir, f"{Path(fn).stem}.npy")
        np.save(save_path, features[i])

# 主处理流程
image_batch = []
filenames = []

for idx, img_path in enumerate(Path(Config.image_dir).glob("*.*")):
    try:
        # 读取并预处理图像
        image = Image.open(img_path).convert("RGB")
        tensor = preprocess(image)
        
        # 累积批次
        image_batch.append(tensor)
        filenames.append(img_path.name)
        
        # 达到批次大小时处理
        if len(image_batch) == Config.batch_size:
            process_batch(image_batch, filenames)
            image_batch, filenames = [], []
            print(f"Processed {idx+1} images")
            
    except Exception as e:
        print(f"Error processing {img_path}: {str(e)}")

# 处理剩余图像
if len(image_batch) > 0:
    process_batch(image_batch, filenames)
    print(f"Processed final batch of {len(image_batch)} images")

# 清理资源
hook.remove()
torch.cuda.empty_cache()
