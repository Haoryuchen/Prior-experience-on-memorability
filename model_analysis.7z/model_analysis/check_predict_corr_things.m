clc
clear

load("spose_embedding_49d_sorted.txt")

tbl = readtable('Things_ViT-L14_predictions.csv', 'ReadVariableNames', true);


for i = 1:49

    current_dim(:,i)=table2array(tbl(:,i+1));

    [coeff(i) p(i)]=corr(spose_embedding_49d_sorted(:,i),current_dim(:,i),'type','pearson');

end

r9=length(find(coeff>0.9));


r8=length(find(coeff>0.8));


r7=length(find(coeff>0.7));


r6=length(find(coeff>0.6));