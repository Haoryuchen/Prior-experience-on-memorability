import numpy as np

f1 = np.load("./Things_transformer_activations/Things_0002.npy")
f2 = np.load("./Things_transformer_activations/Things_0222.npy")

print("特征是否相同:", np.allclose(f1, f2))  #若输出True则特征有问题
print("特征形状:", f1.shape, f2.shape)
