import torch
import clip
from PIL import Image

# 加载模型
device = "cuda" if torch.cuda.is_available() else "cpu"
model, preprocess = clip.load("ViT-B/32", device=device)

# 获取中间层输出的钩子函数
activation = {}
def get_activation(name):
    def hook(model, input, output):
        activation[name] = output.detach()
    return hook

# 注册钩子到目标层（ViT倒数第二层）
model.visual.transformer.resblocks[-1].mlp.register_forward_hook(get_activation('penultimate_layer'))

# 处理单张图片
image = preprocess(Image.open("H:\Memorability\EXP1_MEMTEST\model_analysis\Stims\Obj_0101.jpg")).unsqueeze(0).to(device)

with torch.no_grad():
    image_features = model.encode_image(image)
    penultimate_features = activation['penultimate_layer']

print(penultimate_features.shape)  # 应输出类似 torch.Size([1, 197, 768])
