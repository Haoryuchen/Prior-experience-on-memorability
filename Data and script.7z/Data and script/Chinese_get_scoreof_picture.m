clc 
clear

function_dir = which('Chinese_get_score_of_picture.m');

doc_list = dir(fullfile(function_dir(1:end-length(function_dir)-1),'*.csv'));

rating_name=[];rating_score=[];

stim1_name=[];stim1_score=[];

stim2_name=[];stim2_score=[];

for i = 1:length(doc_list)

    file_dir=[doc_list(i).folder '\' doc_list(i).name];

    table=readtable(file_dir);

    mem_index=find(ismember(table.cond,'mem'));

    test_index=find(ismember(table.cond,'test'));

    stim_1=find(ismember(table.stim,doc_list(i).name(9:10)));

    stim_2=find(ismember(table.stim,doc_list(i).name(11:12)));

    stimname{i,:}=doc_list(i).name(9:12);

    rating_index=intersect(stim_1,mem_index);

    stim1_index=stim_1(151:300);

    stim2_index=stim_2;

    if isempty(stim_1)||isempty(stim_2)
        ddddondondonddd;
    end

    rating_name=[rating_name;table.stimulus(rating_index-1)];

    rating_score=[rating_score;table.response(rating_index)];
    

    stim1_name=[stim1_name;table.stimulus(stim1_index)];

    stim1_score=[stim1_score;table.response(stim1_index)];


    stim2_name=[stim2_name;table.stimulus(stim2_index)];

    stim2_score=[stim2_score;table.response(stim2_index)];
    

end

rating_list=[];rating_list_score=[];rating_list_num=[];rating_num=[];

for n = 1:length(rating_score)
    
    seedname=rating_name(n);

    if find(ismember(rating_list,rating_name{n}))


    else
        rating_list=[rating_list;seedname];

        rating_num=[rating_num;str2num(rating_name{n}(end-7:end-4))];

        pic_index_rate=find(ismember(rating_name,rating_name{n}));
        
        rating_list_score=[rating_list_score;mean(6-str2num(cell2mat(rating_score(pic_index_rate))))];

        rating_list_num=[rating_list_num;length(pic_index_rate)];

    end

end


stim1_list=[];stim1_list_score=[];stim1_list_num=[];stim1_num=[];

for n = 1:length(stim1_score)
    
    seedname=stim1_name(n);

    if find(ismember(stim1_list,stim1_name{n}))


    else
        stim1_list=[stim1_list;seedname];

        stim1_num=[stim1_num;str2num(stim1_name{n}(end-7:end-4))];

        pic_index_rate=find(ismember(stim1_name,stim1_name{n}));
        
        stim1_list_score=[stim1_list_score;mean(1+str2num(cell2mat(stim1_score(pic_index_rate))))];

        stim1_list_num=[stim1_list_num;length(pic_index_rate)];

    end

end



stim2_list=[];stim2_list_score=[];stim2_list_num=[];stim2_num=[];

for n = 1:length(stim1_score)
    
    seedname=stim2_name(n);

    if find(ismember(stim2_list,stim2_name{n}))


    else
        stim2_list=[stim2_list;seedname];

        stim2_num=[stim2_num;str2num(stim2_name{n}(end-7:end-4))];

        pic_index_rate=find(ismember(stim2_name,stim2_name{n}));
        
        stim2_list_score=[stim2_list_score;mean(1+str2num(cell2mat(stim2_score(pic_index_rate))))];

        stim2_list_num=[stim2_list_num;length(pic_index_rate)];

    end

end


[rating_sort,rating_ind]=sort(rating_num);


[stim1_sort,stim1_ind]=sort(stim1_num);


[stim2_sort,stim2_ind]=sort(stim2_num);


sort_rating_score=rating_list_score(rating_ind);


sort_stim1_score=stim1_list_score(stim1_ind);


sort_stim2_score=stim2_list_score(stim2_ind);


sort_stim_score=sort_stim2_score-sort_stim1_score;%full score
% 
% sort_stim_score=6-sort_stim1_score;%only old score

save('Chinese_ratingandtesting.mat','sort_rating_score','sort_stim1_score','sort_stim2_score','sort_stim_score');



%% counting the number of data

stimmlist=unique(stimname);
for i=1:length(stimmlist)

     stimmlist{i,2}=length(find(ismember(stimname,stimmlist{i})));
end