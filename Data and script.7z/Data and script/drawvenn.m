
function [Rproportion,h] = drawvenn(top_vi_se_res_ch_stats,top_res_ch_stats,top_vi_res_ch_stats)
% first enter full model,second semantic model, third visual model
    SemanticR=top_vi_se_res_ch_stats(1)-top_vi_res_ch_stats(1);
    VisualR=top_vi_se_res_ch_stats(1)-top_res_ch_stats(1);
    shareR=top_vi_se_res_ch_stats(1)-SemanticR-VisualR;

    if shareR<0
    shareR1=0;
    elseif shareR>0
    shareR1=shareR;
    end
    semantic_variance=[1:floor(SemanticR*10000),floor(SemanticR*10000)+1:floor(SemanticR*10000)+floor(shareR1*10000)];


    visual_variance=[floor(SemanticR*10000)+floor(shareR1*10000):floor(SemanticR*10000)+floor(shareR1*10000)+floor(VisualR*10000),floor(SemanticR*10000):floor(SemanticR*10000)+floor(shareR1*10000)];

    setListData={semantic_variance,visual_variance};

    setlabels={'Semantic';'Visual'};

    h=vennEulerDiagram(setListData, setlabels, 'drawProportional', true);


    h.SetLabels = [];

    Rproportion=[SemanticR,VisualR,shareR];
end