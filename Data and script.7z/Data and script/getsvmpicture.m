
%% this is for svm of different picuter

function[seq_of_feature,classloss,minpos]=getsvmpicture(dim49_score,am_better,ch_better)

green=[102 194 165]/256;

gray=[148 155 147]/256;


am_better_score=dim49_score(am_better,:);

ch_better_score=dim49_score(ch_better,:);

spec_better=[am_better_score;ch_better_score];

index=[ones([length(am_better) 1]);2*ones([length(ch_better) 1])];

select_feature=spec_better;

select_index=index;


for i = 1:49
betalist=[];   
for iter=1:10
mdl=fitcsvm(select_feature,select_index,'CrossVal','on','KFold',6);

classloss(iter,i) = kfoldLoss(mdl);
    

    for n = 1:6
        betalist(iter,n,:)=mdl.Trained{n,1}.Beta;
    
    end

end

    meanbeta=squeeze(mean(mean(betalist,1),2))';

    index_of_min_beta=find(abs(meanbeta)==min(abs(meanbeta)));

    identify_feature=select_feature(:,index_of_min_beta);

    select_feature(:,index_of_min_beta)=[];

    for ni=1:49
          pos(ni)=isequal(identify_feature,spec_better(:,ni));
    end
    
seq_of_feature(i)=find(pos);
end

load('labels_short.mat');

figure
    x=[1:49];
    y=1-movmean(squeeze(mean(classloss,1)),7);
    minpos=find(y==max(y))
    minclassloss=max(y)
    colormatrix=repmat(gray,[49 1]);
    colormatrix(minpos:end,:)=repmat(green,[49-minpos+1 1]);
    hold on
    for i = 1:49
    h=barh(i,y(i),'FaceColor',colormatrix(i,:));
    end
    yticks([1:49]);
    yticlable=wordPairs(seq_of_feature);
    xlabel('Classification correct rate')
    ylabel('Importance of the feature')
    set(gcf,'Position',[595,97,410,715])
    yticklabels(yticlable);
    set(gca,'XAxisLocation','top');   
    set(gca, 'Box', 'off');    
    set(gca, 'YDir', 'reverse');
    set(gca,'XLim',[min(y) max(y)])
        

end
    