clc
clear

ch=load('Chinese_ratingandtesting.mat');

am=load('American_ratingandtesting.mat');

tbl = readtable('49dimensions_predictions/brady_ViT-L14_predictions.csv', 'ReadVariableNames', true);


ch_predict=ch.sort_rating_score;

am_predict=am.sort_rating_score;

ch_recognition=ch.sort_stim_score;

am_recognition=-am.sort_stim_score;

resmem_predict=am.resmem;

red=[254,93,96]/256;

blue=[111,163,207]/256;

%% chinese prediction of chinese memory


figure
    g=gramm('x',ch_predict,'y',ch_recognition);
    [r,p]=corr(ch_predict,ch_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','Chinese prediction of memory','y','Chinese memorability');
    g.set_color_options('map','brewer')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw(); 
    pbaspect(g.facet_axes_handles,[1 1 1])
    g.export('file_name','chinese_predict_export','file_type','png');

    print(gcf, '-dpng', '-r600', './chinese_predict_export.png')

figure
    g=gramm('x',ch_predict,'y',am_recognition);
    [r,p]=corr(ch_predict,am_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','Chinese prediction of memory','y','American memorability');
    g.set_color_options('map','d3_20')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])


    print(gcf, '-dpng', '-r600', './chinese_predict_American_export.png')


figure
    g=gramm('x',resmem_predict,'y',ch_recognition);
    [r,p]=corr(resmem_predict,ch_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','resmem prediction of memory','y','Chinese memorability');
    g.set_color_options('map','brewer')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])

    print(gcf, '-dpng', '-r600', './resmem_predict_Chinese_export.png')

% chinese pure prediction
 coefficients=polyfit(am_predict,ch_predict,1);
 fitted_values = polyval(coefficients,am_predict);
 ch_predict_residual=ch_predict-fitted_values;

figure
    g=gramm('x',ch_predict_residual,'y',ch_recognition);
    [r,p]=corr(ch_predict_residual,ch_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','Residual(Chinese prediction - American prediction)','y','Chinese memorability');
    g.set_color_options('map','brewer')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])

    print(gcf, '-dpng', '-r600', './Chinese_pure_predict_Chinese_export.png')

figure
    g=gramm('x',ch_predict_residual,'y',am_recognition);
    [r,p]=corr(ch_predict_residual,am_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','Residual(Chinese prediction - American prediction)','y','Americane memorability');
    g.set_color_options('map','d3_20')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])

    print(gcf, '-dpng', '-r600', './Chinese_pure_predict_American_export.png')

figure
    g=gramm('x',am_predict,'y',am_recognition);
    [r,p]=corr(am_predict,am_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','American prediction of memory','y','American memorability');
    g.set_color_options('map','d3_20')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])
    print(gcf, '-dpng', '-r600', './American_predict_export.png')

figure
    g=gramm('x',resmem_predict,'y',am_recognition);
    [r,p]=corr(resmem_predict,am_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','resmem prediction of memory','y','American memorability');
    g.set_color_options('map','d3_20')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])
    g.export('file_name','','file_type','png');

print(gcf, '-dpng', '-r600', './resmem_predict_American_export.png')


figure
    g=gramm('x',am_predict,'y',ch_recognition);
    [r,p]=corr(am_predict,ch_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','American prediction of memory','y','Chinese memorability');
    g.set_color_options('map','brewer')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])
    print(gcf, '-dpng', '-r600', './American_predict_Chinese_export.png')


% chinese pure prediction
 coefficients=polyfit(ch_predict,am_predict,1);
 fitted_values = polyval(coefficients,ch_predict);
 am_predict_residual=am_predict-fitted_values;

figure
    g=gramm('x',am_predict_residual,'y',am_recognition);
    [r,p]=corr(am_predict_residual,am_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','Residual(American prediction - Chinese prediction)','y','American memorability');
    g.set_color_options('map','d3_20')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])
    g.export('file_name',['American_pure_predict_American_export'],'file_type','png');


figure
    g=gramm('x',am_predict_residual,'y',ch_recognition);
    [r,p]=corr(am_predict_residual,ch_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','Residual(American prediction - Chinese prediction)','y','Chinese memorability');
    g.set_color_options('map','brewer')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])
    g.export('file_name',['American_pure_predict_Chinese_export'],'file_type','png');

    
figure
    g=gramm('x',ch_recognition,'y',am_recognition);
    [r,p]=corr(ch_recognition,am_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','Chinese memorability','y','American memorability');
    g.set_color_options('map','brewer2')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])
    g.export('file_name','chinese_memory_American_memory_export','file_type','png');



figure
    g=gramm('x',ch_predict,'y',am_predict);
    [r,p]=corr(ch_predict,am_predict,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','Chinese prediction of memory','y','American prediction of memory');
    g.set_color_options('map','brewer2')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])
    g.export('file_name','chinese_predict_American_predict_export','file_type','png');


figure
    g=gramm('x',ch_predict,'y',resmem_predict);
    [r,p]=corr(ch_predict,resmem_predict,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','Chinese prediction of memory','y','resmem prediction of memory');
    g.set_color_options('map','brewer2')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])
    g.export('file_name','chinese_predict_resmem_predict_export','file_type','png');


 figure
    g=gramm('x',am_predict,'y',resmem_predict);
    [r,p]=corr(am_predict,resmem_predict,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','American prediction of memory','y','resmem prediction of memory');
    g.set_color_options('map','brewer2')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw();
    pbaspect(g.facet_axes_handles,[1 1 1])
    g.export('file_name','American_predict_resmem_predict_export','file_type','png');

%% memory prediction correlate with object dimension

coefficients=polyfit(ch_recognition,am_recognition,1);
fitted_values = polyval(coefficients,ch_recognition);
am_memorability_residual=am_recognition-fitted_values;

coefficients=polyfit(am_recognition,ch_recognition,1);
fitted_values = polyval(coefficients,am_recognition);
ch_memorability_residual=ch_recognition-fitted_values;


for i = 1:49

    dim49_score(:,i)=table2array(tbl(:,i+1));

    [coeff_ch_prediction_dim(i) ch_pred_p(i)]=corr(ch_predict,dim49_score(:,i),'type','Spearman');

    [coeff_am_prediction_dim(i) am_pred_p(i)]=corr(am_predict,dim49_score(:,i),'type','Spearman');


    [coeff_ch_memorability_dim(i) ch_memorability_p(i)]=corr(ch_recognition,dim49_score(:,i),'type','Spearman');

    [coeff_am_memorability_dim(i) am_memorability_p(i)]=corr(am_recognition,dim49_score(:,i),'type','Spearman');


    [coeff_ch_resid_pred_dim(i) ch_resid_pred_p(i)]=corr(ch_predict_residual,dim49_score(:,i),'type','Spearman');

    [coeff_am_resid_pred_dim(i) am_resid_pred_p(i)]=corr(am_predict_residual,dim49_score(:,i),'type','Spearman');


    [coeff_ch_resid_memo_dim(i) ch_resid_memo_p(i)]=corr(ch_memorability_residual,dim49_score(:,i),'type','Spearman');

    [coeff_am_resid_memo_dim(i) am_resid_memo_p(i)]=corr(am_memorability_residual,dim49_score(:,i),'type','Spearman');
end


find(am_memorability_p<0.05)



[ch_memo_dims,ch_memo_coeff]=get_fdr_dims(ch_memorability_p,coeff_ch_memorability_dim);

[am_memo_dims,am_memo_coeff]=get_fdr_dims(am_memorability_p,coeff_am_memorability_dim);

load("labels_short.mat");
load('labels.mat');

for i=1:size(labels_short,2)
    labels_short{i}(1)=upper(labels_short{i}(1));

    labels{i}(1)=upper(labels{i}(1));
end

labels_short=labels_short';

labels_sort=[1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 2, 1, 1, 1, 2, 1, 1, 3, 1, 2, 3, 3, 2, 1, 1, 3, 1, 1, 1, 2, 1, 3, 2, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 3, 1, 1, 3, 1, 2]';

wordPairs = {
    'metal/artificial',          % 1 (语义类)
    'food/eating',               % 1
    'animal/organic',            % 1
    'clothing/fabric',           % 1
    'furniture/household',       % 1
    'plant/green',               % 3 (混合类: green是颜色)
    'outdoors/nature',           % 1 (原outdoors/related)
    'transportation/motorized',  % 1
    'wood/brownish',             % 3 (混合类: brownish是颜色)
    'body/hand',                 % 1 (原body/related)
    'colorful/colorful',         % 2 (视觉类)
    'valuable/special',          % 1
    'electronic/technology',     % 1
    'sport/recreational',        % 1
    'disc/round',                % 2 (视觉类)
    'tool/hammer',               % 1 (原tool/related)
    'small/pattern',             % 1
    'paper/flat',                % 3 (混合类: flat是形状)
    'fluid/drink',               % 1
    'long/thin',                 % 2 (视觉类)
    'water/blue',                % 3 (混合类: blue是颜色)
    'powdery/pattern',           % 3 (混合类: pattern是形状)
    'red/red',                   % 2 (视觉类)
    'feminine/decorative',       % 1
    'bathroom/sanitary',         % 1
    'black/noble',               % 3 (混合类: black是颜色)
    'weapon/danger',             % 1
    'musical/noise',             % 1
    'sky/flying',                % 1
    'spherical/rounded',         % 2 (视觉类)
    'repetitive/loop',           % 1 (原repetitive/related)
    'flat/patterned',            % 3 (混合类: flat是形状)
    'white/white',               % 2 (视觉类)
    'thin/flat',                 % 2 (视觉类)
    'disgusting/bugs',           % 1
    'string/rope',               % 1 (原string/related)
    'arms/skin',                 % 1
    'shiny/transparent',         % 2 (视觉类)
    'construction/work',         % 1
    'fire/heat',                 % 1
    'head/face',                 % 1
    'beams/wood',                % 1 (原beams/related)
    'seating/put',               % 1
    'container/hollow',          % 1
    'child/toy',                 % 3 (混合类: toy非颜色/形状)
    'medicine/pill',             % 1 (原medicine/related)
    'grating/metal',             % 3 (混合类: grating隐含形状)
    'handicraft/knitting',       % 1 (原handicraft/related)
    'cylindrical/conical'        % 2 (视觉类)
};

for i=1:size(wordPairs,1)
    wordPairs{i}(1)=upper(wordPairs{i}(1));

    labels{i}(1)=upper(labels{i}(1));
end



save("labels_short.mat","labels_short",'labels_sort','wordPairs');

[index_of_positive_ch,sort_labels_ch,sort_ch_memorability_coeff,index_of_sort_ch]=sort_get_index(coeff_ch_memorability_dim,wordPairs,ch_memo_dims);


[index_of_positive_am,sort_labels_am,sort_am_memorability_coeff,index_of_sort_am]=sort_get_index(coeff_am_memorability_dim,wordPairs,am_memo_dims);



%% Plot for chinese participant
red=[240 155 160];
blue=[68 133 199];

figure
    x=[1:49];
    y=sort_ch_memorability_coeff;
    ylabel=sort_labels_ch;
    barh(x,y,'FaceColor',red/256)
    set(gca, 'YDir', 'reverse');
    set(gca,'XAxisLocation','top');   
    xlim([-floor(max(10*abs(y)))/10-0.1,abs(-floor(max(10*abs(y)))/10-0.1)])
    set(gca,'ytick',x, 'yticklabel',ylabel)
    set(gca, 'FontName','Arial')
    set(gcf,'Position',[595,97,410,715])
    set(gca, 'Box', 'off');
    set(gca,'looseInset',[0 0 0 0])
    title({'Chinese Rank correlation between '; 'dimensions and memorability'},'FontWeight','bold')
    saveas(gca,'Chinese_Rank_correlation','png')

figure
    x=[1:49];
    y=sort_am_memorability_coeff;
    ylabel=sort_labels_am;
    barh(x,y,'FaceColor',blue/256)
    set(gca, 'YDir', 'reverse');
    set(gca,'XAxisLocation','top');   
    xlim([-floor(max(10*abs(y)))/10-0.1,abs(-floor(max(10*abs(y)))/10-0.1)])
    set(gca,'ytick',x, 'yticklabel',ylabel)
    set(gca, 'FontName','Arial')
    set(gcf,'Position',[595,97,410,715])
    set(gca, 'Box', 'off');
    set(gca,'looseInset',[0 0 0 0])
    title({'American Rank correlation between '; 'dimensions and memorability'},'FontWeight','bold')
    saveas(gca,'American_Rank_correlation','png')
%% Clarify the Semantic dimensions and visual dimensions
Semantic_index=find(labels_sort==1);

Visual_index=find(labels_sort==2);

mixed_index=find(labels_sort==3);

Semantic_name=wordPairs(Semantic_index);

Visual_name=wordPairs(Visual_index);

mixed_name=wordPairs(mixed_index);

%% Semantic, Visual correlation
semantic_score=dim49_score(:,Semantic_index);

visual_score=dim49_score(:,Visual_index);

semantic_visual_score=dim49_score(:,[Semantic_index;Visual_index]);

mixed_score=dim49_score(:,mixed_index);


%% get top nine predictor

[~,index_of_abs_chse_seq]=sort(abs(coeff_ch_memorability_dim(Semantic_index)));%得到的是最大相关自变量在原序列中的位置

top9_semantic_index_china=Semantic_index(index_of_abs_chse_seq(end-8:end));

[~,index_of_abs_amse_seq]=sort(abs(coeff_am_memorability_dim(Semantic_index)));%得到的是最大相关自变量在原序列中的位置

top9_semantic_index_american=Semantic_index(index_of_abs_amse_seq(end-8:end));

china_only=setdiff(top9_semantic_index_china,top9_semantic_index_american);

american_only=setdiff(top9_semantic_index_american,top9_semantic_index_china);

top_semantic_score_ch=dim49_score(:,top9_semantic_index_china);

top_semantic_score_am=dim49_score(:,top9_semantic_index_american);

%% get top nine embedded semantic dimension
dim49_embedded_count=zeros(size(dim49_score));
for i =1:600
    dim49_embedded_count(i,find(dim49_score(i,:)==max(dim49_score(i,:))))=1;
end

sum_count=sum(dim49_embedded_count,1);

[~,index_of_count]=sort(sum_count(Semantic_index));%得到的是最大相关自变量在原序列中的位置

top9_semantic_index=Semantic_index(index_of_count(end-8:end));

top_semantic_score=dim49_score(:,top9_semantic_index);


[ch49_b,ch49_bint,ch49_r,ch49_rint,ch49_stats] = regress(ch_recognition,[ones([600 1]) dim49_score]);

[am49_b,am49_bint,am49_r,am49_rint,am49_stats] = regress(am_recognition,[ones([600 1]) dim49_score]);

[chse_b,chse_bint,chse_r,chse_rint,chse_stats] = regress(ch_recognition,[ones([600 1]) semantic_score]);

[amse_b,amse_bint,amse_r,amse_rint,amse_stats] = regress(am_recognition,[ones([600 1]) semantic_score]);

[chvi_b,chvi_bint,chvi_r,chvi_rint,chvi_stats] = regress(ch_recognition,[ones([600 1]) visual_score]);

[amvi_b,amvi_bint,amvi_r,amvi_rint,amvi_stats] = regress(am_recognition,[ones([600 1]) visual_score]);

[tpchse_b,tpchse_bint,tpchse_r,tpchse_rint,tpchse_stats] = regress(ch_recognition,[ones([600 1]) top_semantic_score_ch]);

[tpamse_b,tpamse_bint,tpamse_r,tpamse_rint,tpamse_stats] = regress(am_recognition,[ones([600 1]) top_semantic_score_am]);

[tpechse_b,tpechse_bint,tpechse_r,tpechse_rint,tpechse_stats] = regress(ch_recognition,[ones([600 1]) top_semantic_score]);

[tpeamse_b,tpeamse_bint,tpeamse_r,tpeamse_rint,tpeamse_stats] = regress(am_recognition,[ones([600 1]) top_semantic_score]);

%%Residual memorability; get residual memorability

[am_ch_b,am_ch_bint,am_ch_r,am_ch_rint,am_ch_stats] = regress(ch_recognition,[ones([600 1]) am_recognition]);

[ch_am_b,ch_am_bint,ch_am_r,ch_am_rint,ch_am_stats] = regress(am_recognition,[ones([600 1]) ch_recognition]);
%% semantic regression
[se_res_ch_b,se_res_ch_bint,se_res_ch_r,se_res_ch_rint,se_res_ch_stats] = regress(am_ch_r,[ones([600 1]) semantic_score]);

[se_res_am_b,se_res_am_bint,se_res_am_r,se_res_am_rint,se_res_am_stats] = regress(ch_am_r,[ones([600 1]) semantic_score]);

[vi_se_res_ch_b,vi_se_res_ch_bint,vi_se_res_ch_r,vi_se_res_ch_rint,vi_se_res_ch_stats] = regress(am_ch_r,[ones([600 1]) semantic_score visual_score]);

[vi_se_res_am_b,vi_se_res_am_bint,vi_se_res_am_r,vi_se_res_am_rint,vi_se_res_am_stats] = regress(ch_am_r,[ones([600 1]) semantic_score visual_score]);

%% top regression
[top_res_ch_b,top_res_ch_bint,top_res_ch_r,top_res_ch_rint,top_res_ch_stats] = regress(am_ch_r,[ones([600 1]) top_semantic_score]);

[top_res_am_b,top_res_am_bint,top_res_am_r,top_res_am_rint,top_res_am_stats] = regress(ch_am_r,[ones([600 1]) top_semantic_score]);

[top_vi_res_ch_b,top_vi_res_ch_bint,top_vi_res_ch_r,top_vi_res_ch_rint,top_vi_res_ch_stats] = regress(am_ch_r,[ones([600 1]) visual_score]);

[top_vi_res_am_b,top_vi_res_am_bint,top_vi_res_am_r,top_vi_res_am_rint,top_vi_res_am_stats] = regress(ch_am_r,[ones([600 1]) visual_score]);

[top_vi_se_res_ch_b,top_vi_se_res_ch_bint,top_vi_se_res_ch_r,top_vi_se_res_ch_rint,top_vi_se_res_ch_stats] = regress(am_ch_r,[ones([600 1]) top_semantic_score visual_score]);

[top_vi_se_res_am_b,top_vi_se_res_am_bint,top_vi_se_res_am_r,top_vi_se_res_am_rint,top_vi_se_res_am_stats] = regress(ch_am_r,[ones([600 1]) top_semantic_score visual_score]);


%% compare the residual
[h_se_ch_am,p_se_ch_am]=ttest(abs(se_res_ch_r-vi_se_res_ch_r),abs(se_res_am_r-vi_se_res_ch_r),'Tail','left');

[h_vi_ch_am,p_vi_ch_am]=ttest(abs(top_vi_res_ch_r-vi_se_res_ch_r),abs(top_vi_res_am_r-vi_se_res_ch_r),'Tail','left');

%draw venn diagramm
figure
[ch_R_proportion,h] = drawvenn(top_vi_se_res_ch_stats,top_res_ch_stats,top_vi_res_ch_stats);
saveas(gca,'Chinese_residual_variance_proportion','png')

figure
[am_R_proportion,h] = drawvenn(top_vi_se_res_am_stats,top_res_am_stats,top_vi_res_am_stats);
saveas(gca,'American_residual_variance_proportion','png')

figure
[ch_R_all_proportion,h] = drawvenn(vi_se_res_ch_stats,se_res_ch_stats,top_vi_res_ch_stats);
saveas(gca,'Chinese_full_model_residual_variance_proportion','png')

figure
[am_R_all_proportion,h] = drawvenn(vi_se_res_am_stats,se_res_am_stats,top_vi_res_am_stats);
saveas(gca,'American_full_model_residual_variance_proportion','png')


[semantic_residual_unique_ch_39]=get_unique_residual(ch_recognition,vi_se_res_ch_r,top_vi_res_ch_r);

[semantic_residual_unique_am_39]=get_unique_residual(am_recognition,vi_se_res_am_r,top_vi_res_am_r);


[visual_residual_unique_ch_39]=get_unique_residual(ch_recognition,vi_se_res_ch_r,top_res_ch_r);

[visual_residual_unique_am_39]=get_unique_residual(am_recognition,vi_se_res_am_r,top_res_am_r);

residual_data_39=[semantic_residual_unique_ch_39';semantic_residual_unique_am_39';visual_residual_unique_ch_39';visual_residual_unique_am_39'];

[h_semantic_39,p_semantic_39]=ttest(abs(semantic_residual_unique_ch_39),abs(semantic_residual_unique_am_39),'Tail','left');

[h_visual_39,p_visual_39]=ttest(abs(visual_residual_unique_ch_39),abs(visual_residual_unique_am_39),'Tail','left');

Y=[semantic_residual_unique_ch_39,semantic_residual_unique_am_39,visual_residual_unique_ch_39,visual_residual_unique_am_39];

S=[1:600,1:600,1:600,1:600];

semantic_visual_index=[ones([1 1200]),2*ones([1 1200])];

ch_am_index=[ones([1 600]),2*ones([1 600]),ones([1 600]),2*ones([1 600])];

p=rm_anova2(Y,S,semantic_visual_index,ch_am_index,{'dimension','country'});


%% Residual of prediction

[top_se_ch_resi_b,top_se_ch_resi_bint,top_se_ch_resi_r,top_se_ch_resi_rint,top_se_ch_resi_stats] = regress(ch_predict_residual,[ones([600 1]) top_semantic_score]);

[top_se_am_resi_b,top_se_am_resi_bint,top_se_am_resi_r,top_se_am_resi_rint,top_se_am_resi_stats] = regress(am_predict_residual,[ones([600 1]) top_semantic_score]);

[top_vi_res_ch_resi_b,top_vi_res_ch_resi_bint,top_vi_res_ch_resi_r,top_vi_res_ch_resi_rint,top_vi_res_ch_resi_stats] = regress(ch_predict_residual,[ones([600 1]) visual_score]);

[top_vi_res_am_resi_b,top_vi_res_am_resi_bint,top_vi_res_am_resi_r,top_vi_res_am_resi_rint,top_vi_res_am_resi_stats] = regress(am_predict_residual,[ones([600 1]) visual_score]);



%% clarify the significant dimensions

ch_pos1=find(index_of_positive_ch==1);

ch_pos3=find(index_of_positive_ch==3);

am_pos1=find(index_of_positive_am==1);

am_pos3=find(index_of_positive_am==3);


ch_pos1_words=sort_labels_ch(ch_pos1);

ch_pos3_words=sort_labels_ch(ch_pos3);

am_pos1_words=sort_labels_am(am_pos1);

am_pos3_words=sort_labels_am(am_pos3);

intersect(ch_pos1_words,am_pos3_words);

intersect(ch_pos1_words,am_pos1_words);




%% predictions of memorability


function [index_of_positive,sort_labels_ch,sort_ch_memorability_coeff,index_of_sort_ch]=sort_get_index(coeff_ch_memorability_dim,labels_short,ch_memo_dims)
[sort_ch_memorability_coeff index_of_sort_ch]=sort(coeff_ch_memorability_dim);

sort_labels_ch=labels_short(index_of_sort_ch);

index_of_positive=[];

    for i =1:length(index_of_sort_ch)
        if find(ch_memo_dims==index_of_sort_ch(i))&(coeff_ch_memorability_dim(index_of_sort_ch(i))<0)
            index_of_positive=[index_of_positive 1];
        elseif find(ch_memo_dims==index_of_sort_ch(i))&(coeff_ch_memorability_dim(index_of_sort_ch(i))>0)
            index_of_positive=[index_of_positive 3];
        else
            index_of_positive=[index_of_positive 2];
        end
    end
end


function [dims,coeff]=get_fdr_dims(p,coefficient)

    fdr_q=mafdr(p,'BHFDR','true');

    dims=find(fdr_q<0.05);

    coeff=coefficient(dims);
end