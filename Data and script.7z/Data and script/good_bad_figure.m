clc
clear

ch=load('Chinese_ratingandtesting.mat');

am=load('American_ratingandtesting.mat');

tbl = readtable('49dimensions_predictions/brady_ViT-L14_predictions.csv', 'ReadVariableNames', true);

green=[102 194 165]/256;

gray=[148 155 147]/256;

red=[240,155,160]/256;

red=[254,93,96]/256;

blue=[11,163,227]/256;
blue=[111,163,227]/256;

mixed_color='#b78098';

% blue=[0,47,167]/256;% dream blue

ch_predict=ch.sort_rating_score;

am_predict=am.sort_rating_score;

ch_recognition=ch.sort_stim_score;

am_recognition=-am.sort_stim_score;

resmem_predict=am.resmem;

should_svm=1;

%% split the quardium of data

m_ch_recog=quantile(ch_recognition,0.75);

m_am_recog=quantile(am_recognition,0.75);

memorable_ch_index=find(ch_recognition>=m_ch_recog);

unmemorable_ch_index=find(ch_recognition<quantile(ch_recognition,0.25));

memorable_am_index=find(am_recognition>=m_am_recog);

unmemorable_am_index=find(am_recognition<quantile(am_recognition,0.25));

ch_am_equal_good=intersect(memorable_ch_index,memorable_am_index);

ch_am_equal_bad=intersect(unmemorable_ch_index,unmemorable_am_index);

ch_better=intersect(memorable_ch_index,unmemorable_am_index);

am_better=intersect(memorable_am_index,unmemorable_ch_index);