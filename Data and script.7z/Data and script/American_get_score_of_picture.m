clc 
clear

function_dir = which('American_get_score_of_picture.m');

%% def the group of picture
A1 = ['Obj_0103.jpg'; 'Obj_0105.jpg'; 'Obj_0110.jpg';'Obj_0114.jpg';'Obj_0118.jpg'; 'Obj_0124.jpg'; 'Obj_0127.jpg'; 'Obj_0130.jpg';
'Obj_0133.jpg'; 'Obj_0138.jpg'; 'Obj_0143.jpg'; 'Obj_0145.jpg'; 'Obj_0150.jpg'; 'Obj_0156.jpg'; 'Obj_0158.jpg'; 'Obj_0201.jpg';
'Obj_0208.jpg'; 'Obj_0212.jpg'; 'Obj_0215.jpg'; 'Obj_0218.jpg'; 'Obj_0221.jpg'; 'Obj_0227.jpg'; 'Obj_0231.jpg'; 'Obj_0236.jpg';
'Obj_0237.jpg'; 'Obj_0243.jpg'; 'Obj_0245.jpg'; 'Obj_0249.jpg'; 'Obj_0254.jpg'; 'Obj_0259.jpg'; 'Obj_0304.jpg'; 'Obj_0306.jpg';
'Obj_0311.jpg'; 'Obj_0315.jpg'; 'Obj_0319.jpg'; 'Obj_0321.jpg'; 'Obj_0325.jpg'; 'Obj_0329.jpg'; 'Obj_0334.jpg'; 'Obj_0340.jpg';
'Obj_0342.jpg'; 'Obj_0346.jpg'; 'Obj_0349.jpg'; 'Obj_0353.jpg'; 'Obj_0360.jpg'; 'Obj_0403.jpg'; 'Obj_0406.jpg'; 'Obj_0412.jpg';
'Obj_0415.jpg'; 'Obj_0418.jpg'; 'Obj_0423.jpg'; 'Obj_0426.jpg'; 'Obj_0431.jpg'; 'Obj_0434.jpg'; 'Obj_0437.jpg'; 'Obj_0441.jpg';
'Obj_0446.jpg'; 'Obj_0451.jpg'; 'Obj_0455.jpg'; 'Obj_0460.jpg'; 'Obj_0501.jpg'; 'Obj_0507.jpg'; 'Obj_0510.jpg'; 'Obj_0515.jpg';
'Obj_0519.jpg'; 'Obj_0521.jpg'; 'Obj_0527.jpg'; 'Obj_0532.jpg'; 'Obj_0535.jpg'; 'Obj_0539.jpg'; 'Obj_0542.jpg'; 'Obj_0545.jpg';
'Obj_0549.jpg'; 'Obj_0554.jpg'; 'Obj_0558.jpg'; 'Obj_0602.jpg'; 'Obj_0605.jpg'; 'Obj_0609.jpg'; 'Obj_0615.jpg'; 'Obj_0619.jpg';
'Obj_0621.jpg'; 'Obj_0628.jpg'; 'Obj_0632.jpg'; 'Obj_0636.jpg'; 'Obj_0638.jpg'; 'Obj_0644.jpg';'Obj_0646.jpg'; 'Obj_0649.jpg';
'Obj_0653.jpg'; 'Obj_0658.jpg'; 'Obj_0701.jpg'; 'Obj_0705.jpg'; 'Obj_0709.jpg'; 'Obj_0714.jpg'; 'Obj_0717.jpg'; 'Obj_0721.jpg';
'Obj_0728.jpg'; 'Obj_0729.jpg'; 'Obj_0734.jpg'; 'Obj_0739.jpg'; 'Obj_0742.jpg'; 'Obj_0748.jpg'; 'Obj_0750.jpg'; 'Obj_0756.jpg';
'Obj_0757.jpg'; 'Obj_0801.jpg'; 'Obj_0808.jpg'; 'Obj_0812.jpg'; 'Obj_0816.jpg'; 'Obj_0819.jpg'; 'Obj_0822.jpg'; 'Obj_0827.jpg';
'Obj_0832.jpg'; 'Obj_0835.jpg'; 'Obj_0837.jpg'; 'Obj_0844.jpg'; 'Obj_0846.jpg'; 'Obj_0849.jpg'; 'Obj_0856.jpg';'Obj_0859.jpg';
'Obj_0901.jpg'; 'Obj_0908.jpg'; 'Obj_0909.jpg'; 'Obj_0916.jpg'; 'Obj_0917.jpg'; 'Obj_0922.jpg'; 'Obj_0927.jpg'; 'Obj_0929.jpg';
'Obj_0936.jpg'; 'Obj_0937.jpg'; 'Obj_0944.jpg'; 'Obj_0945.jpg'; 'Obj_0950.jpg'; 'Obj_0953.jpg'; 'Obj_0957.jpg'; 'Obj_1004.jpg';
'Obj_1007.jpg'; 'Obj_1010.jpg';'Obj_1014.jpg'; 'Obj_1018.jpg'; 'Obj_1024.jpg'; 'Obj_1026.jpg';'Obj_1029.jpg';'Obj_1033.jpg';
'Obj_1037.jpg'; 'Obj_1041.jpg'; 'Obj_1048.jpg';'Obj_1051.jpg'; 'Obj_1056.jpg'; 'Obj_1057.jpg'];
A2 = ['Obj_0104.jpg'; 'Obj_0108.jpg'; 'Obj_0112.jpg';'Obj_0116.jpg';'Obj_0120.jpg'; 'Obj_0122.jpg'; 'Obj_0126.jpg'; 'Obj_0129.jpg';
'Obj_0134.jpg'; 'Obj_0140.jpg'; 'Obj_0144.jpg'; 'Obj_0147.jpg'; 'Obj_0152.jpg'; 'Obj_0155.jpg'; 'Obj_0160.jpg'; 'Obj_0204.jpg';
'Obj_0206.jpg'; 'Obj_0211.jpg'; 'Obj_0216.jpg'; 'Obj_0217.jpg'; 'Obj_0223.jpg'; 'Obj_0226.jpg'; 'Obj_0232.jpg'; 'Obj_0235.jpg';
'Obj_0240.jpg'; 'Obj_0242.jpg'; 'Obj_0248.jpg'; 'Obj_0251.jpg'; 'Obj_0256.jpg'; 'Obj_0258.jpg'; 'Obj_0302.jpg'; 'Obj_0308.jpg';
'Obj_0309.jpg'; 'Obj_0314.jpg'; 'Obj_0320.jpg'; 'Obj_0322.jpg'; 'Obj_0326.jpg'; 'Obj_0331.jpg'; 'Obj_0336.jpg'; 'Obj_0338.jpg';
'Obj_0343.jpg'; 'Obj_0347.jpg'; 'Obj_0352.jpg'; 'Obj_0356.jpg'; 'Obj_0357.jpg'; 'Obj_0402.jpg'; 'Obj_0405.jpg'; 'Obj_0411.jpg';
'Obj_0414.jpg'; 'Obj_0420.jpg'; 'Obj_0424.jpg'; 'Obj_0427.jpg'; 'Obj_0430.jpg'; 'Obj_0435.jpg'; 'Obj_0438.jpg'; 'Obj_0442.jpg';
'Obj_0447.jpg'; 'Obj_0450.jpg'; 'Obj_0456.jpg'; 'Obj_0457.jpg'; 'Obj_0504.jpg'; 'Obj_0505.jpg'; 'Obj_0511.jpg'; 'Obj_0516.jpg';
'Obj_0518.jpg'; 'Obj_0524.jpg'; 'Obj_0528.jpg'; 'Obj_0529.jpg'; 'Obj_0534.jpg'; 'Obj_0537.jpg'; 'Obj_0543.jpg'; 'Obj_0548.jpg';
'Obj_0552.jpg'; 'Obj_0553.jpg'; 'Obj_0557.jpg'; 'Obj_0603.jpg'; 'Obj_0607.jpg'; 'Obj_0610.jpg'; 'Obj_0613.jpg'; 'Obj_0617.jpg';
'Obj_0622.jpg'; 'Obj_0627.jpg'; 'Obj_0630.jpg'; 'Obj_0634.jpg'; 'Obj_0639.jpg'; 'Obj_0642.jpg';'Obj_0647.jpg'; 'Obj_0651.jpg';
'Obj_0654.jpg'; 'Obj_0657.jpg'; 'Obj_0702.jpg'; 'Obj_0708.jpg'; 'Obj_0710.jpg'; 'Obj_0715.jpg'; 'Obj_0718.jpg'; 'Obj_0722.jpg';
'Obj_0725.jpg'; 'Obj_0730.jpg'; 'Obj_0735.jpg'; 'Obj_0738.jpg'; 'Obj_0741.jpg'; 'Obj_0746.jpg'; 'Obj_0751.jpg'; 'Obj_0753.jpg';
'Obj_0759.jpg'; 'Obj_0804.jpg'; 'Obj_0807.jpg'; 'Obj_0811.jpg'; 'Obj_0814.jpg'; 'Obj_0817.jpg'; 'Obj_0821.jpg'; 'Obj_0828.jpg';
'Obj_0829.jpg'; 'Obj_0834.jpg'; 'Obj_0840.jpg'; 'Obj_0843.jpg'; 'Obj_0845.jpg'; 'Obj_0851.jpg'; 'Obj_0853.jpg';'Obj_0860.jpg';
'Obj_0903.jpg'; 'Obj_0905.jpg'; 'Obj_0912.jpg'; 'Obj_0915.jpg'; 'Obj_0919.jpg'; 'Obj_0924.jpg'; 'Obj_0926.jpg'; 'Obj_0931.jpg';
'Obj_0933.jpg'; 'Obj_0940.jpg'; 'Obj_0942.jpg'; 'Obj_0947.jpg'; 'Obj_0952.jpg'; 'Obj_0954.jpg'; 'Obj_0959.jpg'; 'Obj_1003.jpg';
'Obj_1006.jpg'; 'Obj_1011.jpg';'Obj_1016.jpg'; 'Obj_1017.jpg'; 'Obj_1021.jpg'; 'Obj_1028.jpg';'Obj_1031.jpg';'Obj_1034.jpg';
'Obj_1038.jpg'; 'Obj_1042.jpg'; 'Obj_1047.jpg';'Obj_1049.jpg'; 'Obj_1053.jpg'; 'Obj_1059.jpg'];
B1 = ['Obj_0102.jpg'; 'Obj_0107.jpg'; 'Obj_0111.jpg';'Obj_0115.jpg';'Obj_0119.jpg'; 'Obj_0121.jpg'; 'Obj_0125.jpg'; 'Obj_0132.jpg';
'Obj_0135.jpg'; 'Obj_0137.jpg'; 'Obj_0142.jpg'; 'Obj_0146.jpg'; 'Obj_0151.jpg'; 'Obj_0153.jpg'; 'Obj_0157.jpg'; 'Obj_0202.jpg';
'Obj_0207.jpg'; 'Obj_0209.jpg'; 'Obj_0213.jpg'; 'Obj_0219.jpg'; 'Obj_0222.jpg'; 'Obj_0225.jpg'; 'Obj_0229.jpg'; 'Obj_0234.jpg';
'Obj_0239.jpg'; 'Obj_0241.jpg'; 'Obj_0247.jpg'; 'Obj_0250.jpg'; 'Obj_0255.jpg'; 'Obj_0260.jpg'; 'Obj_0303.jpg'; 'Obj_0307.jpg';
'Obj_0310.jpg'; 'Obj_0316.jpg'; 'Obj_0318.jpg'; 'Obj_0324.jpg'; 'Obj_0328.jpg'; 'Obj_0330.jpg'; 'Obj_0335.jpg'; 'Obj_0339.jpg';
'Obj_0344.jpg'; 'Obj_0348.jpg'; 'Obj_0350.jpg'; 'Obj_0355.jpg'; 'Obj_0359.jpg'; 'Obj_0404.jpg'; 'Obj_0408.jpg'; 'Obj_0409.jpg';
'Obj_0416.jpg'; 'Obj_0419.jpg'; 'Obj_0422.jpg'; 'Obj_0428.jpg'; 'Obj_0429.jpg'; 'Obj_0436.jpg'; 'Obj_0439.jpg'; 'Obj_0443.jpg';
'Obj_0445.jpg'; 'Obj_0452.jpg'; 'Obj_0454.jpg'; 'Obj_0459.jpg'; 'Obj_0503.jpg'; 'Obj_0508.jpg'; 'Obj_0509.jpg'; 'Obj_0514.jpg';
'Obj_0517.jpg'; 'Obj_0522.jpg'; 'Obj_0525.jpg'; 'Obj_0530.jpg'; 'Obj_0533.jpg'; 'Obj_0540.jpg'; 'Obj_0541.jpg'; 'Obj_0546.jpg';
'Obj_0551.jpg'; 'Obj_0555.jpg'; 'Obj_0560.jpg'; 'Obj_0601.jpg'; 'Obj_0606.jpg'; 'Obj_0611.jpg'; 'Obj_0614.jpg'; 'Obj_0618.jpg';
'Obj_0623.jpg'; 'Obj_0626.jpg'; 'Obj_0629.jpg'; 'Obj_0635.jpg'; 'Obj_0637.jpg'; 'Obj_0643.jpg';'Obj_0648.jpg'; 'Obj_0650.jpg';
'Obj_0655.jpg'; 'Obj_0660.jpg'; 'Obj_0703.jpg'; 'Obj_0706.jpg'; 'Obj_0712.jpg'; 'Obj_0716.jpg'; 'Obj_0720.jpg'; 'Obj_0723.jpg';
'Obj_0726.jpg'; 'Obj_0731.jpg'; 'Obj_0733.jpg'; 'Obj_0737.jpg'; 'Obj_0743.jpg'; 'Obj_0747.jpg'; 'Obj_0752.jpg'; 'Obj_0755.jpg';
'Obj_0758.jpg'; 'Obj_0802.jpg'; 'Obj_0806.jpg'; 'Obj_0810.jpg'; 'Obj_0815.jpg'; 'Obj_0818.jpg'; 'Obj_0823.jpg'; 'Obj_0826.jpg';
'Obj_0831.jpg'; 'Obj_0836.jpg'; 'Obj_0839.jpg'; 'Obj_0841.jpg'; 'Obj_0847.jpg'; 'Obj_0852.jpg'; 'Obj_0855.jpg';'Obj_0857.jpg';
'Obj_0904.jpg'; 'Obj_0906.jpg'; 'Obj_0911.jpg'; 'Obj_0913.jpg'; 'Obj_0918.jpg'; 'Obj_0921.jpg'; 'Obj_0925.jpg'; 'Obj_0932.jpg';
'Obj_0934.jpg'; 'Obj_0939.jpg'; 'Obj_0941.jpg'; 'Obj_0946.jpg'; 'Obj_0949.jpg'; 'Obj_0956.jpg'; 'Obj_0960.jpg'; 'Obj_1002.jpg';
'Obj_1005.jpg'; 'Obj_1009.jpg';'Obj_1013.jpg'; 'Obj_1019.jpg'; 'Obj_1022.jpg'; 'Obj_1025.jpg';'Obj_1032.jpg';'Obj_1036.jpg';
'Obj_1040.jpg'; 'Obj_1044.jpg'; 'Obj_1045.jpg';'Obj_1050.jpg'; 'Obj_1055.jpg'; 'Obj_1058.jpg'];
B2 = ['Obj_0101.jpg';'Obj_0106.jpg';'Obj_0109.jpg';'Obj_0113.jpg';'Obj_0117.jpg'; 'Obj_0123.jpg'; 'Obj_0128.jpg';
'Obj_0131.jpg';'Obj_0136.jpg'; 'Obj_0139.jpg'; 'Obj_0141.jpg';'Obj_0148.jpg';'Obj_0149.jpg'; 'Obj_0154.jpg'; 
'Obj_0159.jpg'; 'Obj_0203.jpg'; 'Obj_0205.jpg'; 'Obj_0210.jpg'; 'Obj_0214.jpg'; 'Obj_0220.jpg'; 'Obj_0224.jpg'; 
'Obj_0228.jpg'; 'Obj_0230.jpg';'Obj_0233.jpg'; 'Obj_0238.jpg';'Obj_0244.jpg'; 'Obj_0246.jpg'; 'Obj_0252.jpg';
'Obj_0253.jpg'; 'Obj_0257.jpg'; 'Obj_0301.jpg'; 'Obj_0305.jpg'; 'Obj_0312.jpg'; 'Obj_0313.jpg'; 'Obj_0317.jpg';
'Obj_0323.jpg';'Obj_0327.jpg'; 'Obj_0332.jpg'; 'Obj_0333.jpg'; 'Obj_0337.jpg';'Obj_0341.jpg'; 'Obj_0345.jpg';
'Obj_0351.jpg';'Obj_0354.jpg'; 'Obj_0358.jpg'; 'Obj_0401.jpg'; 'Obj_0407.jpg'; 'Obj_0410.jpg'; 'Obj_0413.jpg';
'Obj_0417.jpg'; 'Obj_0421.jpg'; 'Obj_0425.jpg'; 'Obj_0432.jpg'; 'Obj_0433.jpg'; 'Obj_0440.jpg'; 'Obj_0444.jpg';
'Obj_0448.jpg'; 'Obj_0449.jpg'; 'Obj_0453.jpg'; 'Obj_0458.jpg'; 'Obj_0502.jpg'; 'Obj_0506.jpg'; 'Obj_0512.jpg';
'Obj_0513.jpg'; 'Obj_0520.jpg'; 'Obj_0523.jpg'; 'Obj_0526.jpg'; 'Obj_0531.jpg'; 'Obj_0536.jpg'; 'Obj_0538.jpg';
'Obj_0544.jpg'; 'Obj_0547.jpg'; 'Obj_0550.jpg'; 'Obj_0556.jpg'; 'Obj_0559.jpg'; 'Obj_0604.jpg'; 'Obj_0608.jpg'; 'Obj_0612.jpg';
'Obj_0616.jpg'; 'Obj_0620.jpg'; 'Obj_0624.jpg'; 'Obj_0625.jpg'; 'Obj_0631.jpg'; 'Obj_0633.jpg'; 'Obj_0640.jpg'; 'Obj_0641.jpg';
'Obj_0645.jpg'; 'Obj_0652.jpg';'Obj_0656.jpg';'Obj_0659.jpg'; 'Obj_0704.jpg'; 'Obj_0707.jpg'; 'Obj_0711.jpg'; 'Obj_0713.jpg';
'Obj_0719.jpg'; 'Obj_0724.jpg'; 'Obj_0727.jpg'; 'Obj_0732.jpg'; 'Obj_0736.jpg'; 'Obj_0740.jpg'; 'Obj_0744.jpg'; 'Obj_0745.jpg';
'Obj_0749.jpg'; 'Obj_0754.jpg'; 'Obj_0760.jpg'; 'Obj_0803.jpg'; 'Obj_0805.jpg'; 'Obj_0809.jpg'; 'Obj_0813.jpg'; 'Obj_0820.jpg';
'Obj_0824.jpg'; 'Obj_0825.jpg'; 'Obj_0830.jpg'; 'Obj_0833.jpg'; 'Obj_0838.jpg'; 'Obj_0842.jpg'; 'Obj_0848.jpg'; 'Obj_0850.jpg';
'Obj_0854.jpg'; 'Obj_0858.jpg'; 'Obj_0902.jpg'; 'Obj_0907.jpg'; 'Obj_0910.jpg'; 'Obj_0914.jpg'; 'Obj_0920.jpg';'Obj_0923.jpg';
'Obj_0928.jpg'; 'Obj_0930.jpg'; 'Obj_0935.jpg';'Obj_0938.jpg'; 'Obj_0943.jpg'; 'Obj_0948.jpg'; 'Obj_0951.jpg'; 'Obj_0955.jpg';
'Obj_0958.jpg'; 'Obj_1001.jpg'; 'Obj_1008.jpg'; 'Obj_1012.jpg'; 'Obj_1015.jpg'; 'Obj_1020.jpg'; 'Obj_1023.jpg'; 'Obj_1027.jpg';
'Obj_1030.jpg';'Obj_1035.jpg';'Obj_1039.jpg';'Obj_1043.jpg'; 'Obj_1046.jpg';'Obj_1052.jpg'; 'Obj_1054.jpg'; 'Obj_1060.jpg'];

%% get the group index

for g = 1:4
    if g ==1
        group=A1;
    elseif g==2
        group=A2;
    elseif g==3
        group=B1;
    elseif g==4
        group=B2;
    end
    for n = 1:150

        picnum(n,g)=str2num(group(n,5:8));

    end
end


%% get the exp data

root_dir='H:\Memorability\EXP\DataStim&Codes\Exp1a\OBJ_JOL_';

real_picnum=[];real_rat=[];

stim_pic_num_old=[];stim_oldnew=[];stimscore=[];

stim_pic_num_new=[];

for g = 1:12
    if g ==1
        name='A1A2';
    elseif g==2
        name='A1B1';
    elseif g==3
        name='A1B2';
    elseif g==4
        name='A2A1';
    elseif g==5
        name='A2B1';
    elseif g==6
        name='A2B2';
    elseif g==7
        name='B1A1';
    elseif g==8
        name='B1A2';
    elseif g==9
        name='B1B2';
    elseif g==10
        name='B2A1';
    elseif g==11
        name='B2A2';
    elseif g==12
        name='B2B1';
    end

    data_dir=[root_dir name '\data'];

    datalist=dir(fullfile(data_dir));

    for sub=1:length(datalist)-3
        dataplace=[datalist(1).folder '\' datalist(sub+3).name '\obj_jol_data.mat' ];
        load(dataplace);
        for n = 1:150
    
            pic_index=obj_jol_data.jol_pic(n+2);
    
            real_picnum=[real_picnum picnum(pic_index,1+floor((g-1)/3))];

            real_rat=[real_rat obj_jol_data.jol_resp(n+2)];
            
        end

        for i=1:300

        stim_pic_num_old=[stim_pic_num_old picnum(obj_jol_data.mem_pic(i),1+floor((g-1)/3))];

        if name(3:4)=='A1'
            index=1;
        elseif name(3:4)=='A2'
            index=2;
        elseif name(3:4)=='B1'
            index=3;
        elseif name(3:4)=='B2'
            index=4;
        end
        stim_pic_num_new=[stim_pic_num_new picnum(obj_jol_data.mem_pic(i),index)];

        stim_oldnew=[stim_oldnew obj_jol_data.mem_oldnew(i)];

        stimscore=[stimscore obj_jol_data.mem_resp(i)];

        end
    end
end

pic_list=sort(unique(real_picnum));

for i = 1:length(pic_list)
    
    picname=pic_list(i);

    rat_index=find(real_picnum==picname);

    sort_rating_score(i,1)=mean(7-real_rat(rat_index));

    
end

pic_list=sort(unique(stim_pic_num_old));

for i = 1:length(pic_list)
    
    picname=pic_list(i);

    stim1_index=intersect(find(stim_pic_num_old==picname),find(stim_oldnew==1));stim2_index=intersect(find(stim_pic_num_new==picname),find(stim_oldnew==2));

    sort_stim1_score(i,1)=mean(7-stimscore(stim1_index)); sort_stim2_score(i,1)=mean(7-stimscore(stim2_index));

    
end

load('export.mat');

sort_stim_score=(sort_stim2_score-sort_stim1_score); %this is used

%sort_stim_score=(-sort_stim1_score);

%sort_stim_score=recognition';

resmem=memorability';


save('American_ratingandtesting.mat','sort_rating_score','sort_stim_score',"resmem");