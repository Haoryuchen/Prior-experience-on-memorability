function[semantic_residual_unique]=get_unique_residual(ch_recognition,vi_se_res_ch_r,vi_res_ch_r)
% get unique residual, 1 enter reconition, 2 enter full model residual, 3
% enter opposite residual.
    semantic_residual_unique=ch_recognition+vi_se_res_ch_r-vi_res_ch_r;

end