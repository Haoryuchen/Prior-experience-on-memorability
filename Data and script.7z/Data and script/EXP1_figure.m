clc
clear

ch=load('Chinese_ratingandtesting.mat');

am=load('American_ratingandtesting.mat');

tbl = readtable('49dimensions_predictions/brady_ViT-L14_predictions.csv', 'ReadVariableNames', true);


ch_predict=ch.sort_rating_score;

am_predict=am.sort_rating_score;

ch_recognition=ch.sort_stim_score;

am_recognition=-am.sort_stim_score;

resmem_predict=am.resmem;

red=[254,93,96]/256;

blue=[111,163,207]/256;

%% chinese prediction of chinese memory

coefficients=polyfit(am_predict,ch_predict,1);
fitted_values = polyval(coefficients,am_predict);
ch_predict_residual=ch_predict-fitted_values;

coefficients=polyfit(ch_predict,am_predict,1);
fitted_values = polyval(coefficients,ch_predict);
am_predict_residual=am_predict-fitted_values;


ch_recognition_use=repmat(ch_recognition,[2 1]);

prediction=[ch_predict,am_predict];

color_inde=[ones([600 1]);2*ones([600 1])];

figure
    g=gramm('x',prediction,'y',ch_recognition_use,'color',color_inde);
    [r,p]=corr(ch_predict,ch_recognition,'Type','Pearson');
    g.geom_point('dodge',1,'alpha',0.83);
    g.stat_glm();
    g.set_names('x','Chinese prediction of memory','y','Chinese memorability');
    g.set_color_options('map','brewer')
    g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
    g.draw(); 
    g.facet_axes_handles.Colormap=[blue];g.facet_axes_handles.ColorOrder=[blue];
    g.draw();
    
    g.export('file_name','predict_chinese_export','file_type','png');

