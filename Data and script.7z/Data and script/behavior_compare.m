% chinese american behavior compare
clc
clear
load("american_Acc.mat")

am_hit=hit_rate;

am_reject=reject_rate;


load("china_Acc.mat")

ch_hit=hit_rate;

ch_reject=reject_rate;

[h,p,~,t]=ttest2(ch_hit,am_hit)

mean(ch_hit)

mean(am_hit)


[h,p,~,t]=ttest2(ch_reject,am_reject)

mean(ch_reject)

mean(am_reject)

ch_acc=(ch_hit+ch_reject)/2;

am_acc=(am_hit+am_reject)/2;


[h,p,~,t]=ttest2(ch_acc,am_acc)



mean(ch_acc)

mean(am_acc)