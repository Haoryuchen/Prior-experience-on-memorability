clc
clear

ch=load('Chinese_ratingandtesting.mat');

am=load('American_ratingandtesting.mat');

tbl = readtable('49dimensions_predictions/brady_ViT-L14_predictions.csv', 'ReadVariableNames', true);

green=[102 194 165]/256;

gray=[148 155 147]/256;

red=[240,155,160]/256;

red=[254,93,96]/256;

blue=[11,163,227]/256;
blue=[111,163,227]/256;

mixed_color='#b78098';

% blue=[0,47,167]/256;% dream blue

ch_predict=ch.sort_rating_score;

am_predict=am.sort_rating_score;

ch_recognition=ch.sort_stim_score;

am_recognition=-am.sort_stim_score;

resmem_predict=am.resmem;

should_svm=1;

%% split the quardium of data

[h,p,ci,t]=ttest(ch_recognition,am_recognition);

m_ch_recog=median(ch_recognition);

m_am_recog=median(am_recognition);

memorable_ch_index=find(ch_recognition>=m_ch_recog);

unmemorable_ch_index=find(ch_recognition<m_ch_recog);

memorable_am_index=find(am_recognition>=m_am_recog);

unmemorable_am_index=find(am_recognition<m_am_recog);

ch_am_equal_good=intersect(memorable_ch_index,memorable_am_index);

ch_am_equal_bad=intersect(unmemorable_ch_index,unmemorable_am_index);

ch_better=intersect(memorable_ch_index,unmemorable_am_index);

am_better=intersect(memorable_am_index,unmemorable_ch_index);

 figure
    h=scatter(ch_recognition,am_recognition,[],green,'filled','MarkerFaceAlpha',.8,'MarkerEdgeAlpha',1);
    [yrange]=get(gca,"yLim");
    [xrange]=get(gca,"xLim");
    xhalf=max(abs(xrange-m_ch_recog));
    set(gca,'xlim',[m_ch_recog-xhalf,m_ch_recog+xhalf]);
    yhalf=max(abs(yrange-m_am_recog));
    set(gca,'ylim',[m_am_recog-yhalf,m_am_recog+yhalf]);
    set(gca,'fontsize',15);
    [yrange]=get(gca,"yLim");
    [xrange]=get(gca,"xLim");
    line([m_ch_recog m_ch_recog],[min(yrange),max(yrange)],'color',gray,'Linestyle','-.')
    line([min(xrange) max(xrange)],[m_am_recog,m_am_recog],'color',gray,'Linestyle','-.')
    p = polyfit(ch_recognition, am_recognition, 1); % 一次拟合
    x_fit=linspace(xrange(1),xrange(2),600);
    yfit = polyval(p,x_fit); % 计算拟合后的y值
    hold on
% 绘制散点图
    plot(x_fit, yfit,'Color',gray); % 绘制散点图，黑色点
    [r,p]=corr(ch_recognition,am_recognition,'Type','Pearson');
    % title(['r = ' num2str(r) ', p = ' num2str(p)],'FontWeight','bold','FontSize',15)
    % xlabel('Chinese memorability', 'FontSize', 15)
    % ylabel('American memorabilty', 'FontSize', 15)

    % pbaspect([0.6 1 1])

    xleft=xrange(1)+1/10*(xrange(2)-xrange(1));
    xright=xrange(2)-1/10*(xrange(2)-xrange(1));
    ylow=yrange(1)+1/10*(yrange(2)-yrange(1));
    yhigh=yrange(2)-1/10*(yrange(2)-yrange(1));

    text(xleft,yhigh,num2str(length(am_better)),'FontSize',12,'FontWeight','bold');

    text(xleft,ylow,num2str(length(ch_am_equal_bad)),'FontSize',12,'FontWeight','bold');

    text(xright,yhigh,num2str(length(ch_am_equal_good)),'FontSize',12,'FontWeight','bold');

    text(xright,ylow,num2str(length(ch_better)),'FontSize',12,'FontWeight','bold');

    % saveas(gcf,'Chinese_American_memorability_correlation','png')

    print(gcf, '-dpng', '-r600', './Chinese_American_memorability_correlation.png')

%% get cultural specific picture




for i = 1:49

    dim49_score(:,i)=table2array(tbl(:,i+1));

end

am_better_score=dim49_score(am_better,:);

ch_better_score=dim49_score(ch_better,:);

spec_better=[am_better_score;ch_better_score];

index=[ones([length(am_better) 1]);2*ones([length(ch_better) 1])];

select_feature=spec_better;

select_index=index;

 if should_svm==1


for i = 1:49
betalist=[];   
for iter=1
mdl=fitcsvm(select_feature,select_index,'CrossVal','on','KFold',10);

classloss(iter,i) = kfoldLoss(mdl);


    for n = 1:10
        betalist(iter,n,:)=mdl.Trained{n,1}.Beta;

    end

end

    meanbeta=squeeze(mean(mean(betalist,1),2))';

    index_of_min_beta=find(abs(meanbeta)==min(abs(meanbeta)));

    identify_feature=select_feature(:,index_of_min_beta);

    select_feature(:,index_of_min_beta)=[];

    for ni=1:49
          pos(ni)=isequal(identify_feature,spec_better(:,ni));
    end

seq_of_feature(i)=find(pos);
end



 end

load('labels_short.mat');
 % 
 % save('SVMfordifferenceinmemorability short','seq_of_feature',"classloss");


 load('SVMfordifferenceinmemorability.mat');

x=[1:49];
    y=1-movmean(squeeze(mean(classloss,1)),7);
    minpos_culturaldiff=find(y==max(y))
    minpos=minpos_culturaldiff;
    minclassloss=max(y)

figure
    colormatrix=repmat(gray,[49 1]);
    colormatrix(minpos:end,:)=repmat(green,[49-minpos+1 1]);
    hold on
    for i = 1:49
    h=barh(i,y(i),'FaceColor',colormatrix(i,:));
    end
    yticks([1:49]);
    yticlable=wordPairs(seq_of_feature);
    xlabel('Classification correct rate')
    ylabel('Importance of the feature')
    set(gcf,'Position',[595,97,410,715])
    yticklabels(yticlable);
    set(gca,'XAxisLocation','top');   
    set(gca, 'Box', 'off');    
    set(gca, 'YDir', 'reverse');
    set(gca,'XLim',[min(y) max(y)])
    set(gca,'fontsize',11)

 print(gcf, '-dpng', '-r600', './important features for distingushing memorable picture.png')

%% for memorable and unmemorable picture





% test of all picture difference

[h_all_am_ch,p_all_am_ch,~,stats_all_am_ch] = ttest2(am_better_score,ch_better_score,'Tail','right');

[h_all_ch_am,p_all_ch_am,~,stats_all_ch_am] = ttest2(am_better_score,ch_better_score,'Tail','left');

am_all_index=find(h_all_am_ch);

ch_all_index=find(h_all_ch_am);

am_all_big_labels=wordPairs(am_all_index);

ch_all_big_labels=wordPairs(ch_all_index);

all_index=[am_all_index,ch_all_index];

am_all_score=mean(am_better_score(:,all_index),1);

ch_all_score=mean(ch_better_score(:,all_index),1);

[~,score_index]=sort(am_all_score-ch_all_score,'descend');

am_all_score=am_all_score(score_index);

ch_all_score=ch_all_score(score_index);

all_labels=wordPairs(all_index(score_index));

t_am_ch=stats_all_am_ch.tstat(all_index(score_index))

t_ch_am=stats_all_ch_am.tstat(all_index(score_index))

sort_index=all_index(score_index);

pamch=p_all_am_ch(sort_index);

pcham=p_all_ch_am(sort_index);

figure
combined_data=[am_all_score;ch_all_score];
h=bar(1:length(all_labels), combined_data, 'Grouped', 'EdgeColor', 'k','Barwidth',1);
set(h(1),'Facecolor',blue)
set(h(2),'Facecolor',red)
set(gca,'XTickLabel',all_labels)
% legend('American memorable picture','China memorable picture')
ylim([0 1])
set(gca,'XTickLabel',all_labels,'fontsize',14)

for i = 1:length(all_labels)

    
    if 0.01<p_all_am_ch(sort_index(i))&&p_all_am_ch(sort_index(i))<0.05

        text(i,am_all_score(i)+0.01,"*",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.001<p_all_am_ch(sort_index(i))&&p_all_am_ch(sort_index(i))<0.01
        
        text(i,am_all_score(i)+0.01,"**",'FontSize',22,'HorizontalAlignment','center')

    elseif p_all_am_ch(sort_index(i))&&p_all_am_ch(sort_index(i))<0.001
        
        text(i,am_all_score(i)+0.01,"***",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.01<p_all_ch_am(sort_index(i))&&p_all_ch_am(sort_index(i))<0.05

        text(i,ch_all_score(i)+0.01,"*",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.001<p_all_ch_am(sort_index(i))&&p_all_ch_am(sort_index(i))<0.01
        
        text(i,ch_all_score(i)+0.01,"**",'FontSize',22,'HorizontalAlignment','center')

    elseif p_all_ch_am(sort_index(i))&&p_all_ch_am(sort_index(i))<0.001
        
        text(i,ch_all_score(i)+0.01,"***",'FontSize',22,'HorizontalAlignment','center')

    end

end

print(gcf, '-dpng', '-r600', './Difference between memorable image in different culture.png')



% test of all picture difference
% two tails
 
[h_all_am_ch,p_all_am_ch,~,stats_all_am_ch] = ttest2(am_better_score,ch_better_score,'Tail','both','Alpha',0.05);

am_all_index=find(p_all_am_ch<0.05);

am_all_big_labels=wordPairs(am_all_index);

all_index=[am_all_index];

am_all_score=mean(am_better_score(:,all_index),1);

ch_all_score=mean(ch_better_score(:,all_index),1);

[~,score_index]=sort(am_all_score-ch_all_score,'descend');

am_all_score=am_all_score(score_index);

ch_all_score=ch_all_score(score_index);

all_labels=wordPairs(all_index(score_index));

p_all_am_ch=p_all_am_ch(all_index(score_index));

t_val=stats_all_am_ch.tstat(all_index(score_index));

figure
combined_data=[am_all_score;ch_all_score];
h=bar(1:length(all_labels), combined_data, 'Grouped', 'EdgeColor', 'k','BarWidth',1);
set(h(1),'Facecolor',blue)
set(h(2),'Facecolor',red)
set(gca,'XTickLabel',all_labels,'fontsize',14)
% legend('American memorable picture','China memorable picture')


for i = 1:length(all_labels)

    if 0.01<p_all_am_ch(i)&&p_all_am_ch(i)<0.05&&am_all_score(i)>ch_all_score(i)

        text(i,am_all_score(i)+0.01,"*",'FontSize',24,'HorizontalAlignment','center')

    elseif 0.001<p_all_am_ch(i)&&p_all_am_ch(i)<0.01&&am_all_score(i)>ch_all_score(i)
        
        text(i,am_all_score(i)+0.01,"**",'FontSize',24,'HorizontalAlignment','center')

    elseif p_all_am_ch(i)&&p_all_am_ch(i)<0.001&&am_all_score(i)>ch_all_score(i)
        
        text(i,am_all_score(i)+0.01,"***",'FontSize',24,'HorizontalAlignment','center')

    elseif 0.01<p_all_am_ch(i)&&p_all_am_ch(i)<0.05&&am_all_score(i)<ch_all_score(i)

        text(i,ch_all_score(i)+0.01,"*",'FontSize',24,'HorizontalAlignment','center')

    elseif 0.001<p_all_am_ch(i)&&p_all_am_ch(i)<0.01&&am_all_score(i)<ch_all_score(i)
        
        text(i,ch_all_score(i)+0.01,"**",'FontSize',24,'HorizontalAlignment','center')

    elseif p_all_am_ch(i)<0.001&&am_all_score(i)<ch_all_score(i)
        
        text(i,ch_all_score(i)+0.01,"***",'FontSize',24,'HorizontalAlignment','center')

    end

end


print(gcf, '-dpng', '-r600', './Difference between memorable image in different culture two tails.png')

%% one tails


dimcross=seq_of_feature(minpos_culturaldiff:end);

am_dim_cross_score=am_better_score(:,dimcross);

ch_dim_cross_score=ch_better_score(:,dimcross);

wordPairs_dim_cross=wordPairs(dimcross);

%% picture that has no significant difference two tails


[h_am_ch,p_am_ch,stats_am_ch] = ttest2(am_dim_cross_score,ch_dim_cross_score,'Tail','both','Alpha',0.1);


%p_am_ch=mafdr(p_am_ch,'BHFDR','true');
% % % 
%  p_ch_am=mafdr(p_ch_am,'BHFDR','true');

am_big_labels=wordPairs_dim_cross;

ch_big_labels=wordPairs_dim_cross;

all_index=[1:length(wordPairs_dim_cross)];

am_all_score=mean(am_dim_cross_score(:,all_index),1);

ch_all_score=mean(ch_dim_cross_score(:,all_index),1);

[~,score_index]=sort(am_all_score-ch_all_score,'descend');

am_all_score=am_all_score(score_index);

ch_all_score=ch_all_score(score_index);

all_labels=wordPairs_dim_cross(all_index(score_index));

p_all_am_ch=p_am_ch(all_index(score_index));


figure

combined_data=[am_all_score;ch_all_score];
h=bar(1:length(all_labels), combined_data, 'Grouped', 'EdgeColor', 'k');
set(h(1),'Facecolor',blue)
set(h(2),'Facecolor',red)
xticks(1:length(all_labels))
set(gca,'XTickLabel',all_labels)
legend('American memorable picture','China memorable picture','Location','SouthOutside')

for i = 1:length(all_labels)

    sort_index=score_index;
    if 0.01<p_all_am_ch(i)&&p_all_am_ch(i)<0.05&&am_all_score(i)>ch_all_score(i)

        text(i,am_all_score(i)+0.01,"*",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.001<p_all_am_ch(i)&&p_all_am_ch(i)<0.01&&am_all_score(i)>ch_all_score(i)
        
        text(i,am_all_score(i)+0.01,"**",'FontSize',22,'HorizontalAlignment','center')

    elseif p_all_am_ch(i)&&p_all_am_ch(i)<0.001&&am_all_score(i)>ch_all_score(i)
        
        text(i,am_all_score(i)+0.01,"***",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.01<p_all_am_ch(i)&&p_all_am_ch(i)<0.05&&am_all_score(i)<ch_all_score(i)

        text(i,ch_all_score(i)+0.01,"*",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.001<p_all_am_ch(i)&&p_all_am_ch(i)<0.01&&am_all_score(i)<ch_all_score(i)
        
        text(i,ch_all_score(i)+0.01,"**",'FontSize',22,'HorizontalAlignment','center')

    elseif p_all_am_ch(i)&&p_all_am_ch(i)<0.001&&am_all_score(i)<ch_all_score(i)
        
        text(i,ch_all_score(i)+0.01,"***",'FontSize',22,'HorizontalAlignment','center')

    end

end

saveas(gcf,'Difference between memorable image in different culture selected by svm sig all two tails','png')%% picture that has no significant difference two tails


[h_am_ch,p_am_ch,stats_am_ch] = ttest2(am_dim_cross_score,ch_dim_cross_score,'Tail','both','Alpha',0.1);


p_am_ch=mafdr(p_am_ch,'BHFDR','true');
% % % 
%  p_ch_am=mafdr(p_ch_am,'BHFDR','true');

am_big_labels=wordPairs_dim_cross;

ch_big_labels=wordPairs_dim_cross;

all_index=[1:length(wordPairs_dim_cross)];

am_all_score=mean(am_dim_cross_score(:,all_index),1);

ch_all_score=mean(ch_dim_cross_score(:,all_index),1);

[~,score_index]=sort(am_all_score-ch_all_score,'descend');

am_all_score=am_all_score(score_index);

ch_all_score=ch_all_score(score_index);

all_labels=wordPairs_dim_cross(all_index(score_index));

p_all_am_ch=p_am_ch(all_index(score_index));


figure

combined_data=[am_all_score;ch_all_score];
h=bar(1:length(all_labels), combined_data, 'Grouped', 'EdgeColor', 'k');
set(h(1),'Facecolor',blue)
set(h(2),'Facecolor',red)
xticks(1:length(all_labels))
set(gca,'XTickLabel',all_labels)
legend('American memorable picture','China memorable picture','Location','SouthOutside')

for i = 1:length(all_labels)

    sort_index=score_index;
    if 0.01<p_all_am_ch(i)&&p_all_am_ch(i)<0.05&&am_all_score(i)>ch_all_score(i)

        text(i,am_all_score(i)+0.01,"*",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.001<p_all_am_ch(i)&&p_all_am_ch(i)<0.01&&am_all_score(i)>ch_all_score(i)
        
        text(i,am_all_score(i)+0.01,"**",'FontSize',22,'HorizontalAlignment','center')

    elseif p_all_am_ch(i)&&p_all_am_ch(i)<0.001&&am_all_score(i)>ch_all_score(i)
        
        text(i,am_all_score(i)+0.01,"***",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.01<p_all_am_ch(i)&&p_all_am_ch(i)<0.05&&am_all_score(i)<ch_all_score(i)

        text(i,ch_all_score(i)+0.01,"*",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.001<p_all_am_ch(i)&&p_all_am_ch(i)<0.01&&am_all_score(i)<ch_all_score(i)
        
        text(i,ch_all_score(i)+0.01,"**",'FontSize',22,'HorizontalAlignment','center')

    elseif p_all_am_ch(i)&&p_all_am_ch(i)<0.001&&am_all_score(i)<ch_all_score(i)
        
        text(i,ch_all_score(i)+0.01,"***",'FontSize',22,'HorizontalAlignment','center')

    end

end

saveas(gcf,'Difference between memorable image in different culture selected by svm sig all two tail fdr','png')


[h_am_ch,p_am_ch,stats_am_ch] = ttest2(am_dim_cross_score,ch_dim_cross_score,'Tail','both','Alpha',0.1);


p_am_ch=mafdr(p_am_ch(find(h_am_ch)),'BHFDR','true');
% % % 
%  p_ch_am=mafdr(p_ch_am,'BHFDR','true');

am_big_labels=wordPairs_dim_cross;

ch_big_labels=wordPairs_dim_cross;

all_index=find(h_am_ch);

am_all_score=mean(am_dim_cross_score(:,all_index),1);

ch_all_score=mean(ch_dim_cross_score(:,all_index),1);

[~,score_index]=sort(am_all_score-ch_all_score,'descend');

am_all_score=am_all_score(score_index);

ch_all_score=ch_all_score(score_index);

all_labels=wordPairs_dim_cross(all_index(score_index));

p_all_am_ch=p_am_ch(score_index);


figure

combined_data=[am_all_score;ch_all_score];
h=bar(1:length(all_labels), combined_data, 'Grouped', 'EdgeColor', 'k');
set(h(1),'Facecolor',blue)
set(h(2),'Facecolor',red)
xticks(1:length(all_labels))
set(gca,'XTickLabel',all_labels)
legend('American memorable picture','China memorable picture','Location','SouthOutside')

for i = 1:length(all_labels)

    sort_index=score_index;
    if 0.01<p_all_am_ch(i)&&p_all_am_ch(i)<0.05&&am_all_score(i)>ch_all_score(i)

        text(i,am_all_score(i)+0.01,"*",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.001<p_all_am_ch(i)&&p_all_am_ch(i)<0.01&&am_all_score(i)>ch_all_score(i)
        
        text(i,am_all_score(i)+0.01,"**",'FontSize',22,'HorizontalAlignment','center')

    elseif p_all_am_ch(i)&&p_all_am_ch(i)<0.001&&am_all_score(i)>ch_all_score(i)
        
        text(i,am_all_score(i)+0.01,"***",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.01<p_all_am_ch(i)&&p_all_am_ch(i)<0.05&&am_all_score(i)<ch_all_score(i)

        text(i,ch_all_score(i)+0.01,"*",'FontSize',22,'HorizontalAlignment','center')

    elseif 0.001<p_all_am_ch(i)&&p_all_am_ch(i)<0.01&&am_all_score(i)<ch_all_score(i)
        
        text(i,ch_all_score(i)+0.01,"**",'FontSize',22,'HorizontalAlignment','center')

    elseif p_all_am_ch(i)&&p_all_am_ch(i)<0.001&&am_all_score(i)<ch_all_score(i)
        
        text(i,ch_all_score(i)+0.01,"***",'FontSize',22,'HorizontalAlignment','center')

    end

end

saveas(gcf,'Difference between memorable image in different culture selected by svm sig all two tails sig fdr','png')



% %% Another way to get outliers
% [am_b,am_bint,am_r,am_rint,am_stats] = regress(ch_recognition,[ones([600 1]) am_recognition]);
% 
% [ch_b,ch_bint,ch_r,ch_rint,ch_stats] = regress(am_recognition,[ones([600 1]) ch_recognition]);
% 
% am_outlier=[];
% 
% ch_outlier=[];
% % 
% % for i = 1:600
% %     if am_rint(i,1)*am_rint(i,2)>0
% %         am_outlier=[am_outlier i];
% % 
% %     end
% % 
% %     if ch_rint(i,1)*ch_rint(i,2)>0
% %         ch_outlier=[ch_outlier i];
% % 
% %     end
% % 
% %     %这样只能选出31个离群值，完全不够分析。
% % end
% 
% mean_r_am=mean(am_r);mean_r_ch=mean(ch_r);
% std_r_am=std(am_r);std_r_ch=std(ch_r);
% 
% for i = 1:600
% 
%     if am_r(i)<mean_r_am-std_r_am
%         am_outlier=[am_outlier 1];%美国更好
% 
%     elseif am_r(i)>mean_r_am+std_r_am
%         am_outlier=[am_outlier 2];%中国更好
% 
%     else
%         am_outlier=[am_outlier 0];
%     end
% 
% end
% 
% ambetterindex=find(am_outlier==1);
% 
% chbetterindex=find(am_outlier==2);
% 
% [seq_of_feature_outlier,classloss_outlier,minpos_outlier]=getsvmpicture(dim49_score,chbetterindex,ambetterindex);


%%
%[seq_of_feature_memorable,classloss_memorablem,minpos_memorable]=getsvmpicture(dim49_score,ch_am_equal_good(1:floor(length(ch_am_equal_good)/2)),ch_am_equal_good(floor(length(ch_am_equal_good)/2)+1:end));


