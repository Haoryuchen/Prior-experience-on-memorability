%编码列表（1:生命, 2:非生命, 3:混合）

clc
clear


red=[254,93,96]/256;

blue=[111,163,207]/256;

mixed_color='#b78098';

% life 13 nonlife 33 version
%dimensions_label=[2, 1, 1, 2, 2, 1, 1, 2, 3, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 2, 1, 1, 3, 2, 2, 3, 1, 2, 2, 2];

% life 9 nonlife 36
%dimensions_label=[2, 1, 1, 2, 2, 1, 3, 2, 3, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 2, 2, 1, 2, 2, 2, 3, 1, 2, 2, 2]

% life 12 nonlife 10
%dimensions_label=[2, 1, 1, 3, 3, 1, 3, 3, 3, 1, 3, 2, 3, 3, 2, 3, 3, 3, 1, 2, 1, 3, 3, 3, 3, 2, 1, 3, 3, 2, 2, 3, 2, 3, 1, 3, 1, 3, 3, 1, 1, 3, 3, 3, 3, 1, 3, 3, 2]

% %编码列表（1:生命, 2:非生命, 3:混合）
%dimensions_label=[2, 1, 1, 2, 2, 1, 1, 2, 3, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 2, 1, 1, 3, 2, 2, 3, 1, 2, 2, 2]

%编码列表 weapon属于
dimensions_label=[2, 3, 1, 2, 2, 1, 3, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 2, 2, 2, 2, 1, 2, 1, 2, 2, 2, 1, 2, 2, 2, 3, 2, 2, 2, 2]

% dimensions_label(27)=1;

% 读取标签名称
load('labels_short.mat');


% 读取49维度分数
tbl = readtable('49dimensions_predictions/brady_ViT-L14_predictions.csv', 'ReadVariableNames', true);

for i = 1:49

    dim49_score(:,i)=table2array(tbl(:,i+1));

end

% 分为三个大维度，生命，非生命，混合

life_index=find(dimensions_label==1);

non_life_index=find(dimensions_label==2);

mixed_index=find(dimensions_label==3);

life_score=dim49_score(:,life_index);

non_life_score=dim49_score(:,non_life_index);

life_labels=wordPairs(life_index);

nonlife_labels=wordPairs(non_life_index);

mixed_labels=wordPairs(mixed_index);




% 训练生命，非生命，混合维度的线性模型，分别预测中国，美国物品可记忆性。

% 读取物品可记忆性分数，以及预测。

ch=load('Chinese_ratingandtesting.mat');

am=load('American_ratingandtesting.mat');

ch_predict=ch.sort_stim_score;

am_predict=-am.sort_stim_score;

ch_recognition=ch.sort_rating_score;

am_recognition=am.sort_rating_score;


[sortcorr,top_nonlife_index]=sort(abs(corr(non_life_score,(am_recognition+ch_recognition)/2)),'descend');

top_nonlife_index=non_life_index(top_nonlife_index);

top_nonlife_index=top_nonlife_index(1:length(life_index));

top_nonlife_score=dim49_score(:,top_nonlife_index);

load("labels.mat")

topnonlabels=labels(top_nonlife_index)

% full model prediction


[~,~,~,~,dim49_ch_stats] = regress(ch_recognition,[ones([600 1]) dim49_score]);


[~,~,~,~,dim49_am_stats] = regress(am_recognition,[ones([600 1]) dim49_score]);



% life model predictions

[life_ch_b,life_ch_bint,life_ch_r,life_ch_rint,life_ch_stats] = regress(ch_recognition,[ones([600 1]) life_score]);


[life_am_b,life_am_bint,life_am_r,life_am_rint,life_am_stats] = regress(am_recognition,[ones([600 1]) life_score]);


% non-life model predictions


[non_life_ch_b,non_life_ch_bint,non_life_ch_r,non_life_ch_rint,non_life_ch_stats] = regress(ch_recognition,[ones([600 1]) non_life_score]);


[non_life_am_b,non_life_am_bint,non_life_am_r,non_life_am_rint,non_life_am_stats] = regress(am_recognition,[ones([600 1]) non_life_score]);


% top nonlife model
[top_nonlife_ch_b,top_nonlife_ch_bint,top_nonlife_ch_r,top_nonlife_ch_rint,top_nonlife_ch_stats] = regress(ch_recognition,[ones([600 1]) top_nonlife_score]);


[top_nonlife_am_b,top_nonlife_am_bint,top_nonlife_am_r,top_nonlife_am_rint,top_nonlife_am_stats] = regress(am_recognition,[ones([600 1]) top_nonlife_score]);



%% 预测可记忆性残差


[~,~,am_recognition_r,~]=regress(am_recognition,[ones([600 1]) ch_recognition]);

[~,~,ch_recognition_r,~]=regress(ch_recognition,[ones([600 1]) am_recognition]);


[~,~,~,~,dim49_ch_stats_r] = regress(ch_recognition_r,[ones([600 1]) dim49_score]);


[~,~,~,~,dim49_am_stats_r] = regress(am_recognition_r,[ones([600 1]) dim49_score]);


% life model

[~,~,r_am_life,~,life_am_residual_stats] = regress(am_recognition_r,[ones([600 1]) life_score])


[~,~,r_chinese_life,~,life_ch_residual_stats] = regress(ch_recognition_r,[ones([600 1]) life_score])

predicted_life_ch=ch_recognition_r-r_chinese_life;

predicted_life_am=am_recognition_r-r_am_life;

% use predict value of life residual model to predict am memorability

[~,~,~,~,cross_life_stats_ch]=regress(am_predict,[ones([600 1]) predicted_life_ch])

[~,~,~,~,cross_life_stats_am]=regress(ch_predict,[ones([600 1]) predicted_life_am])


% life model

[~,~,~,~,non_life_am_residual_stats] = regress(am_recognition_r,[ones([600 1]) non_life_score])


[~,~,~,~,non_life_ch_residual_stats] = regress(ch_recognition_r,[ones([600 1]) non_life_score])


% top non life model

[~,~,~,~,top_nonlife_am_residual_stats] = regress(am_recognition_r,[ones([600 1]) top_nonlife_score])


[~,~,~,~,top_nonlife_ch_residual_stats] = regress(ch_recognition_r,[ones([600 1]) top_nonlife_score])




% 预测方差图figure

[~,~,~,~,top_life_non_life_stats_ch]=regress(ch_recognition_r,[ones([600 1]) life_score top_nonlife_score]);

[~,~,~,~,top_life_non_life_stats_am]=regress(am_recognition_r,[ones([600 1]) life_score top_nonlife_score]);


figure
[ch_R_proportion_top,h] = drawvenn(top_life_non_life_stats_ch,life_ch_residual_stats,top_nonlife_ch_residual_stats);
h.CircleFaceColors=[red;blue]


print(gcf, '-dpng', '-r600', './prediction_top_life_non_life_Chinese_residual_variance_proportion.png')

figure
[am_R_proportion_top,h] = drawvenn(top_life_non_life_stats_am,life_am_residual_stats,top_nonlife_am_residual_stats);
h.CircleFaceColors=[red;blue]


print(gcf, '-dpng', '-r600', './prediction_top_life_non_life_american_residual_variance_proportion.png')


[~,~,~,~,life_non_life_stats_ch]=regress(ch_recognition_r,[ones([600 1]) life_score non_life_score]);

[~,~,~,~,life_non_life_stats_am]=regress(am_recognition_r,[ones([600 1]) life_score non_life_score]);



figure
[ch_R_proportion,h] = drawvenn(life_non_life_stats_ch,life_ch_residual_stats,non_life_ch_residual_stats);
h.CircleFaceColors=[red;blue]

saveas(gca,'prediction_life_non_life_Chinese_residual_variance_proportion','png')

figure
[am_R_proportion,h] = drawvenn(life_non_life_stats_am,life_am_residual_stats,non_life_am_residual_stats);
h.CircleFaceColors=[red;blue]

saveas(gca,'prediction_life_non_life_american_residual_variance_proportion','png')


%% 中美预测可记忆性对可记忆性残差的预测

% figure
%     x=am_predict;
%     y=ch_recognition_r;
%     g=gramm('x',x,'y',y);
%     [r,p]=corr(x,y,'Type','Pearson');
%     g.geom_point('dodge',1,'alpha',0.83);
%     g.stat_glm();
%     g.set_names('x','American prediction of memory','y','Residual(Chinese memorability - American memorability)');
%     g.set_color_options('map','d3_20')
%     g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
%     g.draw();
%     g.export('file_name','American_predict_Chinese_Residual_export','file_type','png');
% 
% 
% figure
%     x=am_predict;
%     y=am_recognition_r;
%     g=gramm('x',x,'y',y);
%     [r,p]=corr(x,y,'Type','Pearson');
%     g.geom_point('dodge',1,'alpha',0.83);
%     g.stat_glm();
%     g.set_names('x','American prediction of memory','y','Residual(American memorability - Chinese memorability)');
%     g.set_color_options('map','d3_20')
%     g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
%     g.draw();
%     g.export('file_name','American_predict_American_Residual_export','file_type','png');    
% 
% 
% figure
%     x=ch_predict;
%     y=ch_recognition_r;
%     g=gramm('x',x,'y',y);
%     [r,p]=corr(x,y,'Type','Pearson');
%     g.geom_point('dodge',1,'alpha',0.83);
%     g.stat_glm();
%     g.set_names('x','Chinese prediction of memory','y','Residual(Chinese memorability - American memorability)');
%     g.set_color_options('map','brewer')
%     g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
%     g.draw();
%     g.export('file_name','Chinese_predict_Chinese_Residual_export','file_type','png');
% 
% 
% figure
%     x=ch_predict;
%     y=am_recognition_r;
%     g=gramm('x',x,'y',y);
%     [r,p]=corr(x,y,'Type','Pearson');
%     g.geom_point('dodge',1,'alpha',0.83);
%     g.stat_glm();
%     g.set_names('x','Chinese prediction of memory','y','Residual(Ameican memorability - Chinese memorability)');
%     g.set_color_options('map','brewer')
%     g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
%     g.draw();
%     g.export('file_name','Chinese_predict_American_Residual_export','file_type','png');


[r_ch_ch_r,p_ch_ch_r]=corr(ch_recognition_r,ch_predict);

[r_am_am_r,p_am_am_r]=corr(am_recognition_r,am_predict);

[r_ch_am_r,p_ch_am_r]=corr(am_recognition_r,ch_predict);

[r_am_ch_r,p_am_ch_r]=corr(ch_recognition_r,am_predict);



% 残差之间的相关

[~,~,ch_predict_r,~,~]=regress(ch_predict,[ones([600 1]) am_predict]);


[~,~,am_predict_r,~,~]=regress(am_predict,[ones([600 1]) ch_predict]);


% figure
%     x=am_predict_r;
%     y=ch_recognition_r;
%     g=gramm('x',x,'y',y);
%     [r,p]=corr(x,y,'Type','Pearson');
%     g.geom_point('dodge',1,'alpha',0.83);
%     g.stat_glm();
%     g.set_names('x','Residual(American prediction - Chinese prediction)','y','Residual(Chinese memorability - American memorability)');
%     g.set_color_options('map','d3_20')
%     g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
%     g.draw();
%     g.export('file_name','American_residual_predict_Chinese_Residual_export','file_type','png');
% 
% 
% figure
%     x=am_predict_r;
%     y=am_recognition_r;
%     g=gramm('x',x,'y',y);
%     [r,p]=corr(x,y,'Type','Pearson');
%     g.geom_point('dodge',1,'alpha',0.83);
%     g.stat_glm();
%     g.set_names('x','Residual(American prediction - Chinese prediction)','y','Residual(American memorability - Chinese memorability)');
%     g.set_color_options('map','d3_20')
%     g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
%     g.draw();
%     g.export('file_name','American_Residual_predict_American_Residual_export','file_type','png');    
% 
% 
% figure
%     x=ch_predict_r;
%     y=ch_recognition_r;
%     g=gramm('x',x,'y',y);
%     [r,p]=corr(x,y,'Type','Pearson');
%     g.geom_point('dodge',1,'alpha',0.83);
%     g.stat_glm();
%     g.set_names('x','Residual(Chinese prediction - American prediction)','y','Residual(Chinese memorability - American memorability)');
%     g.set_color_options('map','brewer')
%     g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
%     g.draw();
%     g.export('file_name','Chinese_Residual_predict_Chinese_Residual_export','file_type','png');
% 
% 
% figure
%     x=ch_predict_r;
%     y=am_recognition_r;
%     g=gramm('x',x,'y',y);
%     [r,p]=corr(x,y,'Type','Pearson');
%     g.geom_point('dodge',1,'alpha',0.83);
%     g.stat_glm();
%     g.set_names('x','Residual(Chinese prediction - American prediction)','y','Residual(Ameican memorability - Chinese memorability)');
%     g.set_color_options('map','brewer')
%     g.set_title(['r = ' num2str(r) ', p = ' num2str(p)]); 
%     g.draw();
%     g.export('file_name','Chinese_Residual_predict_American_Residual_export','file_type','png');



%% 可记忆性预测残差与life模型的相关



 % [~,~,~,~,life_ch_predict_r_stats]=regress(ch_predict_r,[ones([600 1]) life_score]);
 % 
 % 
 % [~,~,~,~,life_am_predict_r_stats]=regress(am_predict_r,[ones([600 1]) life_score]);
 % 
 % 
 % [~,~,~,~,nonlife_ch_predict_r_stats]=regress(ch_predict_r,[ones([600 1]) non_life_score]);
 % 
 % 
 % [~,~,~,~,nonlife_am_predict_r_stats]=regress(am_predict_r,[ones([600 1]) non_life_score]);


% 使用生命维度预测中国可记忆性的残差与美国对物品可记忆性的预测残差相关。

 [~,~,am_r,~]=regress(am_predict,[ones([600 1]) ch_predict]);




%% 排除life score 排名最高的图片之后看美国能否预测中国


