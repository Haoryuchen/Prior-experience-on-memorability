clc 
clear

function_dir = which('Chinese_tendency_of_participant.m');

doc_list = dir(fullfile(function_dir(1:end-length(function_dir)-1),'*.csv'));

rating_name=[];rating_score=[];

stim1_name=[];stim1_score=[];

stim2_name=[];stim2_score=[];

subj_seq=[];

for i = 1:length(doc_list)

    file_dir=[doc_list(i).folder '\' doc_list(i).name];

    table=readtable(file_dir);

    mem_index=find(ismember(table.cond,'mem'));

    test_index=find(ismember(table.cond,'test'));

    stim_1=find(ismember(table.stim,doc_list(i).name(9:10)));

    stim_2=find(ismember(table.stim,doc_list(i).name(11:12)));

    stimname{i,:}=doc_list(i).name(9:12);

    rating_index=intersect(stim_1,mem_index);

    stim1_index=stim_1(151:300);

    stim2_index=stim_2;

    if isempty(stim_1)||isempty(stim_2)
        ddddondondonddd;
    end

    subj_seq=[subj_seq;i*ones(length(table.stimulus(rating_index-1)),1)];

    rating_name=[rating_name;table.stimulus(rating_index-1)];

    rating_score=[rating_score;table.response(rating_index)];
    

    stim1_name=[stim1_name;table.stimulus(stim1_index)];

    stim1_score=[stim1_score;table.response(stim1_index)];


    stim2_name=[stim2_name;table.stimulus(stim2_index)];

    stim2_score=[stim2_score;table.response(stim2_index)];


end

rating_list=[];rating_list_score=[];rating_list_num=[];rating_num=[];

for n = 1:length(rating_score)
    
    seedname=rating_name(n);

    if find(ismember(rating_list,rating_name{n}))


    else
        rating_list=[rating_list;seedname];

        rating_num=[rating_num;str2num(rating_name{n}(end-7:end-4))];

        pic_index_rate=find(ismember(rating_name,rating_name{n}));
        
        rating_list_score=[rating_list_score;mean(6-str2num(cell2mat(rating_score(pic_index_rate))))];

        rating_list_num=[rating_list_num;length(pic_index_rate)];

    end

end


stim1_list=[];stim1_list_score=[];stim1_list_num=[];stim1_num=[];

for n = 1:length(stim1_score)
    
    seedname=stim1_name(n);

    if find(ismember(stim1_list,stim1_name{n}))


    else
        stim1_list=[stim1_list;seedname];

        stim1_num=[stim1_num;str2num(stim1_name{n}(end-7:end-4))];

        pic_index_rate=find(ismember(stim1_name,stim1_name{n}));
        
        stim1_list_score=[stim1_list_score;mean(1+str2num(cell2mat(stim1_score(pic_index_rate))))];

        stim1_list_num=[stim1_list_num;length(pic_index_rate)];

    end

end



stim2_list=[];stim2_list_score=[];stim2_list_num=[];stim2_num=[];

for n = 1:length(stim1_score)
    
    seedname=stim2_name(n);

    if find(ismember(stim2_list,stim2_name{n}))


    else
        stim2_list=[stim2_list;seedname];

        stim2_num=[stim2_num;str2num(stim2_name{n}(end-7:end-4))];

        pic_index_rate=find(ismember(stim2_name,stim2_name{n}));
        
        stim2_list_score=[stim2_list_score;mean(1+str2num(cell2mat(stim2_score(pic_index_rate))))];

        stim2_list_num=[stim2_list_num;length(pic_index_rate)];

    end

end


[rating_sort,rating_ind]=sort(rating_num);


[stim1_sort,stim1_ind]=sort(stim1_num);


[stim2_sort,stim2_ind]=sort(stim2_num);


sort_rating_score=rating_list_score(rating_ind);


sort_stim1_score=stim1_list_score(stim1_ind);


sort_stim2_score=stim2_list_score(stim2_ind);


sort_stim_score=sort_stim2_score-sort_stim1_score;




%% Calculating the proportion of number
sub_acc1=[];sub_acc2=[];

rating_proportion=[];

stim1_proportion=[];

stim2_proportion=[];
for sub = 1:120

i=sub;

    index=find(subj_seq==sub);

    rating_count=5-str2num(cell2mat(rating_score));

    rating_proportion=[rating_proportion length(find(rating_count(index)==0))/length(rating_count(index))];
    
    rating_proportion=[rating_proportion length(find(rating_count(index)==1))/length(rating_count(index))];

    rating_proportion=[rating_proportion length(find(rating_count(index)==2))/length(rating_count(index))];

    rating_proportion=[rating_proportion length(find(rating_count(index)==3))/length(rating_count(index))];

    rating_proportion=[rating_proportion length(find(rating_count(index)==4))/length(rating_count(index))];

    rating_proportion=[rating_proportion length(find(rating_count(index)==5))/length(rating_count(index))];

    rating_proportion_sub(sub,1)=length(find(rating_count(index)==0))/length(rating_count(index));
    
    rating_proportion_sub(sub,2)=length(find(rating_count(index)==1))/length(rating_count(index));

    rating_proportion_sub(sub,3)=length(find(rating_count(index)==2))/length(rating_count(index));

    rating_proportion_sub(sub,4)=length(find(rating_count(index)==3))/length(rating_count(index));

    rating_proportion_sub(sub,5)=length(find(rating_count(index)==4))/length(rating_count(index));

    rating_proportion_sub(sub,6)=length(find(rating_count(index)==5))/length(rating_count(index));


    stim1_count=5-str2num(cell2mat(stim1_score));

    stim1_proportion=[stim1_proportion length(find(stim1_count(index)==0))/length(stim1_count(index))];
    
    stim1_proportion=[stim1_proportion length(find(stim1_count(index)==1))/length(stim1_count(index))];

    stim1_proportion=[stim1_proportion length(find(stim1_count(index)==2))/length(stim1_count(index))];

    stim1_proportion=[stim1_proportion length(find(stim1_count(index)==3))/length(stim1_count(index))];

    stim1_proportion=[stim1_proportion length(find(stim1_count(index)==4))/length(stim1_count(index))];

    stim1_proportion=[stim1_proportion length(find(stim1_count(index)==5))/length(stim1_count(index))];


    stim1_proportion_sub(sub,1)=length(find(stim1_count(index)==0))/length(stim1_count(index));
    
    stim1_proportion_sub(sub,2)=length(find(stim1_count(index)==1))/length(stim1_count(index));

    stim1_proportion_sub(sub,3)=length(find(stim1_count(index)==2))/length(stim1_count(index));

    stim1_proportion_sub(sub,4)=length(find(stim1_count(index)==3))/length(stim1_count(index));

    stim1_proportion_sub(sub,5)= length(find(stim1_count(index)==4))/length(stim1_count(index));

    stim1_proportion_sub(sub,6)= length(find(stim1_count(index)==5))/length(stim1_count(index));


sub_acc1=[sub_acc1 (length(find(stim1_count(index)+1==4))+length(find(stim1_count(index)+1==5))+length(find(stim1_count(index)+1==6)))/length(stim1_count(index))];


stim2_count=5-str2num(cell2mat(stim2_score));


    stim2_proportion=[stim2_proportion length(find(stim2_count(index)==0))/length(stim2_count(index))];
    
    stim2_proportion=[stim2_proportion length(find(stim2_count(index)==1))/length(stim2_count(index))];

    stim2_proportion=[stim2_proportion length(find(stim2_count(index)==2))/length(stim2_count(index))];

    stim2_proportion=[stim2_proportion length(find(stim2_count(index)==3))/length(stim2_count(index))];

    stim2_proportion=[stim2_proportion length(find(stim2_count(index)==4))/length(stim2_count(index))];

    stim2_proportion=[stim2_proportion length(find(stim2_count(index)==5))/length(stim2_count(index))];

    stim2_proportion_sub(sub,1)=length(find(stim2_count(index)==0))/length(stim2_count(index));
    
    stim2_proportion_sub(sub,2)=length(find(stim2_count(index)==1))/length(stim2_count(index));

    stim2_proportion_sub(sub,3)= length(find(stim2_count(index)==2))/length(stim2_count(index));

    stim2_proportion_sub(sub,4)= length(find(stim2_count(index)==3))/length(stim2_count(index));

    stim2_proportion_sub(sub,5)= length(find(stim2_count(index)==4))/length(stim2_count(index));

    stim2_proportion_sub(sub,6)= length(find(stim2_count(index)==5))/length(stim2_count(index));



sub_acc2=[sub_acc2 (length(find(stim2_count(index)+1==1))+length(find(stim2_count(index)+1==2))+length(find(stim2_count(index)+1==3)))/length(stim2_count(index))];

end

mean_rating_proportion_sub=mean(rating_proportion_sub,1)


mean_stim1_proportion_sub=mean(stim1_proportion_sub,1)

mean_stim2_proportion_sub=mean(stim2_proportion_sub,1)

hit_rate=sub_acc1;

reject_rate=sub_acc2;

save('china_Acc.mat',"reject_rate","hit_rate")

%% counting the number of data

mean_rating_proportion=mean(rating_proportion,1);

std_rating_proportion=std(rating_proportion,1);


mean_stim1_proportion=mean(stim1_proportion,1);

std_stim1_proportion=std(stim1_proportion,1);


mean_stim2_proportion=mean(stim2_proportion,1);

std_stim2_proportion=std(stim2_proportion,1);


rating_shape=reshape(rating_proportion,[720 1]);


stim1_shape=reshape(stim1_proportion,[720 1]);


stim2_shape=reshape(stim2_proportion,[720 1]);


stim_shape=[stim2_shape;stim1_shape];

color_index=[2*ones(size(stim1_shape));ones(size(stim2_shape))];

for i = 1:length(color_index)
    if color_index(i)==2
        color_inde{i}='New';
    elseif color_index(i)==1
        color_inde{i}='Old';
    end
end

num_index1=repmat([1:6]',[120 1]);

num_index2=repmat((repmat([1:6]',[120 1])),[2 1]);

stimmlist=unique(stimname);
for i=1:length(stimmlist)

     stimmlist{i,2}=length(find(ismember(stimname,stimmlist{i})));

end


figure
    g=gramm('x',num_index1,'y',rating_shape)
    g.stat_summary('geom',{'bar','black_errorbar'},'setylim',true,'type','ci');
    g.geom_jitter('dodge',0.6,'width',0.5,'alpha',0.3);
    g.set_names('x','Chinese meomory predict confidence level','y','proportion');
    g.set_color_options('map','lch','hue_range',[25 100],'chroma',75,lightness=55);
    g.draw();
    g.facet_axes_handles.YLim=[g.facet_axes_handles.YLim(1) 1];
    g.export('file_name','Chinese Proportion of memory prediction confidence level','file_type','png');
    


figure
    g=gramm('x',num_index2,'y',stim_shape,'color',color_inde)
    g.stat_summary('geom',{'bar','black_errorbar'},'setylim',true,'type','ci');
    g.geom_jitter('dodge',0.6,'width',0.5,'alpha',0.3);
    g.set_names('x','Chinese memory Confidence level','y','proportion');
    g.draw();
    g.facet_axes_handles.YLim=[g.facet_axes_handles.YLim(1) 1];
    g.export('file_name','Chinese Proportion of memory judgement confidence level','file_type','png');



acc1=mean(stim1_shape(find(num_index1==1)))+mean(stim1_shape(find(num_index1==2)))+mean(stim1_shape(find(num_index1==3)));


acc2=mean(stim2_shape(find(num_index1==4)))+mean(stim2_shape(find(num_index1==5)))+mean(stim2_shape(find(num_index1==6)));


acc1=mean(stim1_shape(find(num_index1==1))+stim1_shape(find(num_index1==2))+stim1_shape(find(num_index1==3)));

std1=std(stim1_shape(find(num_index1==1))+stim1_shape(find(num_index1==2))+stim1_shape(find(num_index1==3)));

acc2=mean(stim2_shape(find(num_index1==4))+stim2_shape(find(num_index1==5))+stim2_shape(find(num_index1==6)));

std2=std(stim2_shape(find(num_index1==4))+stim2_shape(find(num_index1==5))+stim2_shape(find(num_index1==6)));